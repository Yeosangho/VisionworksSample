var group__nvx__tutorial__eglstream__interoperability =
[
    [ "Initializing EGL Resources", "group__nvx__tutorial__eglstream__interoperability__1.html", null ],
    [ "Connecting CUDA Consumers to EGL Streams", "group__nvx__tutorial__eglstream__interoperability__2.html", null ],
    [ "Consuming Produced Frames", "group__nvx__tutorial__eglstream__interoperability__3.html", null ],
    [ "Releasing Resources", "group__nvx__tutorial__eglstream__interoperability__4.html", null ]
];