var group__nvx__tutorial__quick__start__graph__mode =
[
    [ "Stabilizer with VisionWorks Graph Mode", "group__nvx__tutorial__quick__start__graph__mode__stabilizer.html", null ]
];