var group__group__vision__function__meanstddev =
[
    [ "vxMeanStdDevNode", "group__group__vision__function__meanstddev.html#gafb589cd4e771de49a7b94e66be6cab48", null ],
    [ "vxuMeanStdDev", "group__group__vision__function__meanstddev.html#ga6f3f336963cc3c6fd9549975906efd79", null ]
];