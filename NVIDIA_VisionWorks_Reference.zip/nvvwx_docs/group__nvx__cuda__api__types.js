var group__nvx__cuda__api__types =
[
    [ "nvxcu_array_t", "group__nvx__cuda__api__types.html#structnvxcu__array__t", [
      [ "array_type", "group__nvx__cuda__api__types.html#a3c519c92c4e3d8a5ec8db3ff27565a60", null ],
      [ "capacity", "group__nvx__cuda__api__types.html#a573661bd4dcdc21fe641da964863aeac", null ],
      [ "item_type", "group__nvx__cuda__api__types.html#a256e8dfa3fd948d89b5005e6ede8213e", null ]
    ] ],
    [ "nvxcu_border_t", "group__nvx__cuda__api__types.html#structnvxcu__border__t", [
      [ "constant_value", "group__nvx__cuda__api__types.html#aebb9584db1c9dc214e12bb0562944060", null ],
      [ "mode", "group__nvx__cuda__api__types.html#ab0694bb7ae6695c79b29e0c4b47c9a14", null ]
    ] ],
    [ "nvxcu_coordinates2d_t", "group__nvx__cuda__api__types.html#structnvxcu__coordinates2d__t", [
      [ "x", "group__nvx__cuda__api__types.html#a8e7971b7f0e74cd4a3b881dec775560b", null ],
      [ "y", "group__nvx__cuda__api__types.html#a7cf1329f668673f96fdfa77dde30d6be", null ]
    ] ],
    [ "nvxcu_coordinates3d_t", "group__nvx__cuda__api__types.html#structnvxcu__coordinates3d__t", [
      [ "x", "group__nvx__cuda__api__types.html#a4b04c9aad0ffa4d2c2b10b7903b5a199", null ],
      [ "y", "group__nvx__cuda__api__types.html#a61f094ec1af1bb185a1f3e270982aa32", null ],
      [ "z", "group__nvx__cuda__api__types.html#a09fdffaaa1a9f92797472ee6323b7826", null ]
    ] ],
    [ "nvxcu_exec_target_t", "group__nvx__cuda__api__types.html#structnvxcu__exec__target__t", [
      [ "exec_target_type", "group__nvx__cuda__api__types.html#a5b7364312bc2da3acb343026ce2025a1", null ]
    ] ],
    [ "nvxcu_image_t", "group__nvx__cuda__api__types.html#structnvxcu__image__t", [
      [ "format", "group__nvx__cuda__api__types.html#a8dfb2206a376d9966f895d38ffff907e", null ],
      [ "height", "group__nvx__cuda__api__types.html#a7b5a37363cd4b79f738efa5054c1a329", null ],
      [ "image_type", "group__nvx__cuda__api__types.html#ae7e51e3c7f37fc356f73a068a0413909", null ],
      [ "width", "group__nvx__cuda__api__types.html#ac0369b45f60759d019e588293d286071", null ]
    ] ],
    [ "nvxcu_keypoint_t", "group__nvx__cuda__api__types.html#structnvxcu__keypoint__t", [
      [ "error", "group__nvx__cuda__api__types.html#ad81bb3e829552e4b3bab44aa2f890ca3", null ],
      [ "orientation", "group__nvx__cuda__api__types.html#ab7f2e0da74d90432a7b0547ee2dfa4ea", null ],
      [ "scale", "group__nvx__cuda__api__types.html#a9766fc6309af916b49dede85bd06211c", null ],
      [ "strength", "group__nvx__cuda__api__types.html#ad65b639d75915618ee98456b6ef9c2a0", null ],
      [ "tracking_status", "group__nvx__cuda__api__types.html#af58e20b74226ae2135def809dc236db4", null ],
      [ "x", "group__nvx__cuda__api__types.html#a6904fbef210dbd43d1eb03d64f56fa92", null ],
      [ "y", "group__nvx__cuda__api__types.html#a70019da95cbd7e3b17feef30d617d3b0", null ]
    ] ],
    [ "nvxcu_keypointf_t", "group__nvx__cuda__api__types.html#structnvxcu__keypointf__t", [
      [ "error", "group__nvx__cuda__api__types.html#a86e2fa4a6404606eb9f238a76faf0005", null ],
      [ "orientation", "group__nvx__cuda__api__types.html#a4a3e0e64cb975a92303427dd508db9cc", null ],
      [ "scale", "group__nvx__cuda__api__types.html#a932373118c505462654ae448e2d10edd", null ],
      [ "strength", "group__nvx__cuda__api__types.html#a3b84e5765269da0290d90997e64f8431", null ],
      [ "tracking_status", "group__nvx__cuda__api__types.html#a86792bee98c0248be2c662cbd90b8042", null ],
      [ "x", "group__nvx__cuda__api__types.html#a05bafae909e41d7d7b41bb5ea1c5c2c5", null ],
      [ "y", "group__nvx__cuda__api__types.html#a61cde8248790af68663f8dd14bcd2c79", null ]
    ] ],
    [ "nvxcu_pitch_linear_image_t", "group__nvx__cuda__api__types.html#structnvxcu__pitch__linear__image__t", [
      [ "base", "group__nvx__cuda__api__types.html#ac0cf5f519179e24ac137366d6fcebca6", null ],
      [ "planes", "group__nvx__cuda__api__types.html#ab8e72082d367df18a0f36a44a5f7849e", null ]
    ] ],
    [ "nvxcu_pitch_linear_image_t.planes", "group__nvx__cuda__api__types.html#structnvxcu__pitch__linear__image__t_8planes", [
      [ "dev_ptr", "group__nvx__cuda__api__types.html#a2ac0dd7c50b555adebc472d2639de9d5", null ],
      [ "pitch_in_bytes", "group__nvx__cuda__api__types.html#ad7971c832223f602f9176e522e811011", null ]
    ] ],
    [ "nvxcu_pitch_linear_pyramid_t", "group__nvx__cuda__api__types.html#structnvxcu__pitch__linear__pyramid__t", [
      [ "base", "group__nvx__cuda__api__types.html#ae557e601edd3a08fd12325e4f54edb2c", null ],
      [ "levels", "group__nvx__cuda__api__types.html#a759e4af75474ef985ce0151669d09350", null ]
    ] ],
    [ "nvxcu_pixel_value_t", "group__nvx__cuda__api__types.html#unionnvxcu__pixel__value__t", [
      [ "F32", "group__nvx__cuda__api__types.html#abbb4aedc3086580f0c3695d58efa4e52", null ],
      [ "F32n", "group__nvx__cuda__api__types.html#abf7cac13fdc8c1875725e7239e3150d8", null ],
      [ "reserved", "group__nvx__cuda__api__types.html#aff0ffb71377977a0b5cce6bef24d7ea2", null ],
      [ "RGB", "group__nvx__cuda__api__types.html#a6ab38b8825e8984670db65490432da1c", null ],
      [ "RGB16", "group__nvx__cuda__api__types.html#a358f27fbb2954b295df623cba6f90056", null ],
      [ "RGBX", "group__nvx__cuda__api__types.html#a1718dca91bd5a12361893f339fcb0482", null ],
      [ "S16", "group__nvx__cuda__api__types.html#a0eb6ce28043b4a02a0430915fc3f3063", null ],
      [ "S16n", "group__nvx__cuda__api__types.html#af25b04c818bd2bbad258c9796e2df903", null ],
      [ "S32", "group__nvx__cuda__api__types.html#a17180208f0513971b741ccc994064351", null ],
      [ "U16", "group__nvx__cuda__api__types.html#aac656f2290c032df3662ffb6ed4a07a3", null ],
      [ "U32", "group__nvx__cuda__api__types.html#abad936a70942b56df1e34f338bb51401", null ],
      [ "U8", "group__nvx__cuda__api__types.html#ad6d5da689305dd9d31b8b9cab9f87b13", null ],
      [ "YUV", "group__nvx__cuda__api__types.html#a8a96f563f772f205e02bbda1a571c74f", null ]
    ] ],
    [ "nvxcu_plain_array_t", "group__nvx__cuda__api__types.html#structnvxcu__plain__array__t", [
      [ "base", "group__nvx__cuda__api__types.html#a9e3d79ff945710be143ee383580dd8d0", null ],
      [ "dev_ptr", "group__nvx__cuda__api__types.html#abd4dc3306912575a8ffb287996452757", null ],
      [ "num_items_dev_ptr", "group__nvx__cuda__api__types.html#abc835b79797f53c1a46a028e79de3630", null ]
    ] ],
    [ "nvxcu_point2f_t", "group__nvx__cuda__api__types.html#structnvxcu__point2f__t", [
      [ "x", "group__nvx__cuda__api__types.html#abf8f4dcc2dafe5c05004df52f61139a4", null ],
      [ "y", "group__nvx__cuda__api__types.html#ad1c7a749e9a55eb76a1f4ee15a27a928", null ]
    ] ],
    [ "nvxcu_point3f_t", "group__nvx__cuda__api__types.html#structnvxcu__point3f__t", [
      [ "x", "group__nvx__cuda__api__types.html#a78e999e3f947f8c404bf5d2fd9f8504c", null ],
      [ "y", "group__nvx__cuda__api__types.html#a14dbb1a6ae1211bcf07aa606d08871db", null ],
      [ "z", "group__nvx__cuda__api__types.html#af3453af9d3b6714dfba4e9fe9a84fb8d", null ]
    ] ],
    [ "nvxcu_point4f_t", "group__nvx__cuda__api__types.html#structnvxcu__point4f__t", [
      [ "w", "group__nvx__cuda__api__types.html#a4162f646f0808ddd48e24e661cbc1c3c", null ],
      [ "x", "group__nvx__cuda__api__types.html#a74d087b70fd49aff4edc281d5394be5c", null ],
      [ "y", "group__nvx__cuda__api__types.html#a399b9b23fbeaf9459358e64a416ac0bf", null ],
      [ "z", "group__nvx__cuda__api__types.html#a012e255e1d9c7dda2a36aeeb1a6e23dc", null ]
    ] ],
    [ "nvxcu_pyramid_t", "group__nvx__cuda__api__types.html#structnvxcu__pyramid__t", [
      [ "num_levels", "group__nvx__cuda__api__types.html#ad21d8134a036054b81578c8d0009cc78", null ],
      [ "pyramid_type", "group__nvx__cuda__api__types.html#af42c3f644deb4aefb1a5ad090af3b778", null ],
      [ "scale", "group__nvx__cuda__api__types.html#ab79cc30765fa0ee22e710b91814d9e1e", null ]
    ] ],
    [ "nvxcu_rectangle_t", "group__nvx__cuda__api__types.html#structnvxcu__rectangle__t", [
      [ "end_x", "group__nvx__cuda__api__types.html#a099cf91c50c03417804f34d8fddeef0e", null ],
      [ "end_y", "group__nvx__cuda__api__types.html#ad29f1262e4cdfa98c46dbdb59fc3715e", null ],
      [ "start_x", "group__nvx__cuda__api__types.html#a8fd986a3cb77b48fe660060699272660", null ],
      [ "start_y", "group__nvx__cuda__api__types.html#aab897f3f2b3075f9e0ab46716d96c01b", null ]
    ] ],
    [ "nvxcu_stream_exec_target_t", "group__nvx__cuda__api__types.html#structnvxcu__stream__exec__target__t", [
      [ "base", "group__nvx__cuda__api__types.html#aded398438459bb26c4e01765c2630e36", null ],
      [ "dev_prop", "group__nvx__cuda__api__types.html#ad02e6f9a34db3364d86a349867015e35", null ],
      [ "stream", "group__nvx__cuda__api__types.html#a90be930c0bb38f3087b4e8979280b8a7", null ]
    ] ],
    [ "nvxcu_tmp_buf_size_t", "group__nvx__cuda__api__types.html#structnvxcu__tmp__buf__size__t", [
      [ "dev_buf_size", "group__nvx__cuda__api__types.html#a2400c283bdf55193416c59f92ea9e4e4", null ],
      [ "host_buf_size", "group__nvx__cuda__api__types.html#a74fed7d9276a1ebe1a93a6349c3ee74d", null ]
    ] ],
    [ "nvxcu_tmp_buf_t", "group__nvx__cuda__api__types.html#structnvxcu__tmp__buf__t", [
      [ "dev_ptr", "group__nvx__cuda__api__types.html#a4c3710b6ba02866807313d3a37114cc1", null ],
      [ "host_ptr", "group__nvx__cuda__api__types.html#a38b138b0166e3b04f8c0a3207d01a2bd", null ]
    ] ],
    [ "nvxcu_uniform_image_t", "group__nvx__cuda__api__types.html#structnvxcu__uniform__image__t", [
      [ "base", "group__nvx__cuda__api__types.html#aadb9a58ff24037ad888e0da31ea64222", null ],
      [ "uniform_value", "group__nvx__cuda__api__types.html#a138e0b394287c403844bed5b0366c428", null ]
    ] ],
    [ "NVXCU_DF_IMAGE", "group__nvx__cuda__api__types.html#gaf7e43428626cd9bfdf0f912b0457a7ce", null ],
    [ "NVXCU_ENUM_BASE", "group__nvx__cuda__api__types.html#gaf310934b62ff4a10b7de9e17dd268249", null ],
    [ "NVXCU_NB_MAX_PLANES", "group__nvx__cuda__api__types.html#gaa312491a2f829febe4c33d736709fa96", null ],
    [ "NVXCU_SCALE_PYRAMID_HALF", "group__nvx__cuda__api__types.html#ga5166f8655ceab9fffdb46aa5be8d3db8", null ],
    [ "NVXCU_SCALE_PYRAMID_ORB", "group__nvx__cuda__api__types.html#ga2d2ffe029cfb1a21a9ccb7fec72e3bc9", null ],
    [ "nvxcu_array_item_type_e", "group__nvx__cuda__api__types.html#gae04feb5c76ec0fe684d93b5cf805bf5d", [
      [ "NVXCU_TYPE_CHAR", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5da8803ca269ae6c54355f755416d88fa44", null ],
      [ "NVXCU_TYPE_INT8", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5da54701968809f3006d3a747f621a24858", null ],
      [ "NVXCU_TYPE_UINT8", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5dad335ed35139747b836956e8898b5bdf3", null ],
      [ "NVXCU_TYPE_INT16", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5dab574618e66743ef39c863473a8ce7251", null ],
      [ "NVXCU_TYPE_UINT16", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5dad71b4c196a5fc62b52560197e6efbc5a", null ],
      [ "NVXCU_TYPE_INT32", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5da38fb5d6cbd91f68dbe9c251d1e1e52fc", null ],
      [ "NVXCU_TYPE_UINT32", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5da003034e5f7ebc822aa6ea81d072a0554", null ],
      [ "NVXCU_TYPE_INT64", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5daafde040bbdf0aa7a9fc452323c54d875", null ],
      [ "NVXCU_TYPE_UINT64", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5daf058d0529b232edbf8227b7f7098003a", null ],
      [ "NVXCU_TYPE_FLOAT32", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5dae10de0a5c5e9b7667a19697a3eb94f97", null ],
      [ "NVXCU_TYPE_FLOAT64", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5daa79d35e87348903556bdbafff97b9759", null ],
      [ "NVXCU_TYPE_RECTANGLE", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5dade837ded2b52bf93eed8279ce9229fbf", null ],
      [ "NVXCU_TYPE_KEYPOINT", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5da3c0b7165d8041de4f7bf13f8d7e76eae", null ],
      [ "NVXCU_TYPE_COORDINATES2D", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5dad74ffe87126d764f217b60e5ac93dcac", null ],
      [ "NVXCU_TYPE_COORDINATES3D", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5da57c077b728b0687d5f77e32f1ecc4469", null ],
      [ "NVXCU_TYPE_POINT2F", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5da0d5414b41ae2fbe8ad93b886ed0212f1", null ],
      [ "NVXCU_TYPE_POINT3F", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5da18abf3f52f0f215bb844ea7afa8c5a80", null ],
      [ "NVXCU_TYPE_POINT4F", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5da996e637f27568561a8afc8c3838ffc2e", null ],
      [ "NVXCU_TYPE_KEYPOINTF", "group__nvx__cuda__api__types.html#ggae04feb5c76ec0fe684d93b5cf805bf5da5a6ef8cdee1d529b15a788ce3ccac815", null ]
    ] ],
    [ "nvxcu_array_type_e", "group__nvx__cuda__api__types.html#ga7ab1fa33e905fc503ddc96677998e045", [
      [ "NVXCU_PLAIN_ARRAY", "group__nvx__cuda__api__types.html#gga7ab1fa33e905fc503ddc96677998e045a3a7049ae55037303df6ae752f7f106b3", null ]
    ] ],
    [ "nvxcu_border_mode_e", "group__nvx__cuda__api__types.html#gad20e31914f511200fc1b3ef1d1e5f0ae", [
      [ "NVXCU_BORDER_MODE_UNDEFINED", "group__nvx__cuda__api__types.html#ggad20e31914f511200fc1b3ef1d1e5f0aea473c66b8c4cac0005291d4fd1eb500a3", null ],
      [ "NVXCU_BORDER_MODE_CONSTANT", "group__nvx__cuda__api__types.html#ggad20e31914f511200fc1b3ef1d1e5f0aead08e22e8f2f104f99d145bf69c51bcd8", null ],
      [ "NVXCU_BORDER_MODE_REPLICATE", "group__nvx__cuda__api__types.html#ggad20e31914f511200fc1b3ef1d1e5f0aea88a59e00d5aa30f045fdeddd2022dce9", null ]
    ] ],
    [ "nvxcu_channel_e", "group__nvx__cuda__api__types.html#ga5c221c23d2be0d595591f8a1f77e896c", [
      [ "NVXCU_CHANNEL_0", "group__nvx__cuda__api__types.html#gga5c221c23d2be0d595591f8a1f77e896ca28612801956aa4e7fb1faf27c14b26db", null ],
      [ "NVXCU_CHANNEL_1", "group__nvx__cuda__api__types.html#gga5c221c23d2be0d595591f8a1f77e896ca6669193ab96a603c0f8a1fcb022dff18", null ],
      [ "NVXCU_CHANNEL_2", "group__nvx__cuda__api__types.html#gga5c221c23d2be0d595591f8a1f77e896ca1c64e3d2299e7ba26e02b8743517f463", null ],
      [ "NVXCU_CHANNEL_3", "group__nvx__cuda__api__types.html#gga5c221c23d2be0d595591f8a1f77e896ca68c01207459d4f9fdcfc82ac613e9446", null ],
      [ "NVXCU_CHANNEL_R", "group__nvx__cuda__api__types.html#gga5c221c23d2be0d595591f8a1f77e896cae904cd85e8317074580e41eea448a95a", null ],
      [ "NVXCU_CHANNEL_G", "group__nvx__cuda__api__types.html#gga5c221c23d2be0d595591f8a1f77e896caf16cfd5281f80c40da0a2555f6d6a4e4", null ],
      [ "NVXCU_CHANNEL_B", "group__nvx__cuda__api__types.html#gga5c221c23d2be0d595591f8a1f77e896cad052e759da51ccf5c8849d601ab60f1f", null ],
      [ "NVXCU_CHANNEL_A", "group__nvx__cuda__api__types.html#gga5c221c23d2be0d595591f8a1f77e896caa8e13b6c94c1fa0c4480e8a287a12b4b", null ],
      [ "NVXCU_CHANNEL_Y", "group__nvx__cuda__api__types.html#gga5c221c23d2be0d595591f8a1f77e896cacb138e566df880e0a6c3f701275e1182", null ],
      [ "NVXCU_CHANNEL_U", "group__nvx__cuda__api__types.html#gga5c221c23d2be0d595591f8a1f77e896ca491098283367dcc2276754a50a275c92", null ],
      [ "NVXCU_CHANNEL_V", "group__nvx__cuda__api__types.html#gga5c221c23d2be0d595591f8a1f77e896ca94eab889e8e81e505f15305a7a6eee17", null ]
    ] ],
    [ "nvxcu_channel_range_e", "group__nvx__cuda__api__types.html#gab42047f3a4023e5a12fb08454db3e05c", [
      [ "NVXCU_CHANNEL_RANGE_FULL", "group__nvx__cuda__api__types.html#ggab42047f3a4023e5a12fb08454db3e05ca9d686db131bebbead83872ac29b818db", null ],
      [ "NVXCU_CHANNEL_RANGE_RESTRICTED", "group__nvx__cuda__api__types.html#ggab42047f3a4023e5a12fb08454db3e05cacaabcfb0b34b71219be54e993017e26a", null ]
    ] ],
    [ "nvxcu_color_space_e", "group__nvx__cuda__api__types.html#ga50d9dfaa48f164ba6ec7ecfdfa714247", [
      [ "NVXCU_COLOR_SPACE_NONE", "group__nvx__cuda__api__types.html#gga50d9dfaa48f164ba6ec7ecfdfa714247a67db8f7039634e2ddc9783623aacd444", null ],
      [ "NVXCU_COLOR_SPACE_BT601_525", "group__nvx__cuda__api__types.html#gga50d9dfaa48f164ba6ec7ecfdfa714247acb7484c920ad50f4d6fcb66b7b15b069", null ],
      [ "NVXCU_COLOR_SPACE_BT601_625", "group__nvx__cuda__api__types.html#gga50d9dfaa48f164ba6ec7ecfdfa714247a0802045eed53ddd6280382b20936e15c", null ],
      [ "NVXCU_COLOR_SPACE_BT709", "group__nvx__cuda__api__types.html#gga50d9dfaa48f164ba6ec7ecfdfa714247a957561bef5f799895d9b0c6425791b72", null ],
      [ "NVXCU_COLOR_SPACE_DEFAULT", "group__nvx__cuda__api__types.html#gga50d9dfaa48f164ba6ec7ecfdfa714247a51e97cfb3f930c008f04fc7ef071ca0c", null ]
    ] ],
    [ "nvxcu_convert_policy_e", "group__nvx__cuda__api__types.html#ga0fc0db0453af1184c2c6db180c52671d", [
      [ "NVXCU_CONVERT_POLICY_WRAP", "group__nvx__cuda__api__types.html#gga0fc0db0453af1184c2c6db180c52671da5e488113ca778decc91b8d2802fa4674", null ],
      [ "NVXCU_CONVERT_POLICY_SATURATE", "group__nvx__cuda__api__types.html#gga0fc0db0453af1184c2c6db180c52671dacd41d6cd0f669d45d97209f4d4cd9d9f", null ]
    ] ],
    [ "nvxcu_df_image_e", "group__nvx__cuda__api__types.html#ga35ac335cdb43328c6ffec26fe2ab5ae2", [
      [ "NVXCU_DF_IMAGE_RGB", "group__nvx__cuda__api__types.html#gga35ac335cdb43328c6ffec26fe2ab5ae2a4e065022507b4b649aebe1e670bde2aa", null ],
      [ "NVXCU_DF_IMAGE_RGBX", "group__nvx__cuda__api__types.html#gga35ac335cdb43328c6ffec26fe2ab5ae2a188018e70807a3ade76d1732b663ea24", null ],
      [ "NVXCU_DF_IMAGE_NV12", "group__nvx__cuda__api__types.html#gga35ac335cdb43328c6ffec26fe2ab5ae2ae8e91fd8c630a55a0a9bfcbe536ed63e", null ],
      [ "NVXCU_DF_IMAGE_NV21", "group__nvx__cuda__api__types.html#gga35ac335cdb43328c6ffec26fe2ab5ae2ada5f5ff36176451d264ea2c9d5e64d9c", null ],
      [ "NVXCU_DF_IMAGE_UYVY", "group__nvx__cuda__api__types.html#gga35ac335cdb43328c6ffec26fe2ab5ae2a8ec211d5da1b671f1c31658561d2b25e", null ],
      [ "NVXCU_DF_IMAGE_YUYV", "group__nvx__cuda__api__types.html#gga35ac335cdb43328c6ffec26fe2ab5ae2a122bf90c5a191aad3d1d6941b5c5136e", null ],
      [ "NVXCU_DF_IMAGE_IYUV", "group__nvx__cuda__api__types.html#gga35ac335cdb43328c6ffec26fe2ab5ae2a5b1aab03273fe160ffbefa0d0a5b36dc", null ],
      [ "NVXCU_DF_IMAGE_YUV4", "group__nvx__cuda__api__types.html#gga35ac335cdb43328c6ffec26fe2ab5ae2a3dac820473026a1690ce387bc64a77b7", null ],
      [ "NVXCU_DF_IMAGE_U8", "group__nvx__cuda__api__types.html#gga35ac335cdb43328c6ffec26fe2ab5ae2a00cfbb3dbed4b743ee35cced2e93ac01", null ],
      [ "NVXCU_DF_IMAGE_U16", "group__nvx__cuda__api__types.html#gga35ac335cdb43328c6ffec26fe2ab5ae2a6ef6a40f8a0947b0786d798d3736e623", null ],
      [ "NVXCU_DF_IMAGE_S16", "group__nvx__cuda__api__types.html#gga35ac335cdb43328c6ffec26fe2ab5ae2a4526494ca1498c7fe5248187cc0f57f1", null ],
      [ "NVXCU_DF_IMAGE_U32", "group__nvx__cuda__api__types.html#gga35ac335cdb43328c6ffec26fe2ab5ae2aa5c4b51e7e0a33c92d87bd12037c12ad", null ],
      [ "NVXCU_DF_IMAGE_S32", "group__nvx__cuda__api__types.html#gga35ac335cdb43328c6ffec26fe2ab5ae2a811704e7be66bf64b547309884925180", null ],
      [ "NVXCU_DF_IMAGE_F32", "group__nvx__cuda__api__types.html#gga35ac335cdb43328c6ffec26fe2ab5ae2a45f185288c79538c6acd27da07137c11", null ],
      [ "NVXCU_DF_IMAGE_2F32", "group__nvx__cuda__api__types.html#gga35ac335cdb43328c6ffec26fe2ab5ae2a6e6c59e536da6cf68684722658be0a1d", null ],
      [ "NVXCU_DF_IMAGE_2S16", "group__nvx__cuda__api__types.html#gga35ac335cdb43328c6ffec26fe2ab5ae2a74fc91cf5dae8777e0d9865163215f05", null ],
      [ "NVXCU_DF_IMAGE_RGB16", "group__nvx__cuda__api__types.html#gga35ac335cdb43328c6ffec26fe2ab5ae2a76aa96ff19f908fe80292e239ae33214", null ]
    ] ],
    [ "nvxcu_enum_e", "group__nvx__cuda__api__types.html#ga1aa983cdf0bf8067e5840e983b627b5c", [
      [ "NVXCU_ENUM_INTERPOLATION", "group__nvx__cuda__api__types.html#gga1aa983cdf0bf8067e5840e983b627b5ca05c35c309733cbbf54f2b9ecb6fa9a90", null ],
      [ "NVXCU_ENUM_COLOR_SPACE", "group__nvx__cuda__api__types.html#gga1aa983cdf0bf8067e5840e983b627b5cad30b030ba2f224630b3b0ad0ea29d858", null ],
      [ "NVXCU_ENUM_COLOR_RANGE", "group__nvx__cuda__api__types.html#gga1aa983cdf0bf8067e5840e983b627b5caf6ef1dbd138d2755e245437163201a74", null ],
      [ "NVXCU_ENUM_CHANNEL", "group__nvx__cuda__api__types.html#gga1aa983cdf0bf8067e5840e983b627b5ca8d2fcc817f9d92da3d0f9f120bd54e6c", null ],
      [ "NVXCU_ENUM_CONVERT_POLICY", "group__nvx__cuda__api__types.html#gga1aa983cdf0bf8067e5840e983b627b5cacda2f15e439151cd7f0e6edbd9ccaaa4", null ],
      [ "NVXCU_ENUM_BORDER_MODE", "group__nvx__cuda__api__types.html#gga1aa983cdf0bf8067e5840e983b627b5cad9f88f8ce63aff60adb1a9fd71a30ea9", null ],
      [ "NVXCU_ENUM_TERM_CRITERIA", "group__nvx__cuda__api__types.html#gga1aa983cdf0bf8067e5840e983b627b5cad1823a9983046eb2d02e3d9cd4aefb73", null ],
      [ "NVXCU_ENUM_NORM_TYPE", "group__nvx__cuda__api__types.html#gga1aa983cdf0bf8067e5840e983b627b5ca8cfe0b455a984cfbb3adea3747d1db07", null ],
      [ "NVXCU_ENUM_ROUND_POLICY", "group__nvx__cuda__api__types.html#gga1aa983cdf0bf8067e5840e983b627b5caf667f150ca015e92c173ffa4b8eddd5a", null ],
      [ "NVXCU_ENUM_NONLINEAR", "group__nvx__cuda__api__types.html#gga1aa983cdf0bf8067e5840e983b627b5cabe786ea598555acf005e032a0c4d2dd9", null ],
      [ "NVXCU_ENUM_PATTERN", "group__nvx__cuda__api__types.html#gga1aa983cdf0bf8067e5840e983b627b5caafaea14733182b1b5aec4113ef065743", null ]
    ] ],
    [ "nvxcu_error_status_e", "group__nvx__cuda__api__types.html#ga95ca9dfa832340593173124fc365b27c", [
      [ "NVXCU_ERROR_CUDA_FAILURE", "group__nvx__cuda__api__types.html#gga95ca9dfa832340593173124fc365b27cac2385e83c6c635d482ea8b8d8af9bf2e", null ],
      [ "NVXCU_ERROR_INVALID_PARAMETERS", "group__nvx__cuda__api__types.html#gga95ca9dfa832340593173124fc365b27ca5a53dd4f3de73e2ebbad7216a4210d67", null ],
      [ "NVXCU_ERROR_NOT_SUPPORTED", "group__nvx__cuda__api__types.html#gga95ca9dfa832340593173124fc365b27ca59a4a0fee1e6897fcb8dfd0787512f88", null ],
      [ "NVXCU_ERROR_NOT_IMPLEMENTED", "group__nvx__cuda__api__types.html#gga95ca9dfa832340593173124fc365b27cafa0ff91312780d2984d261c9d090d9e4", null ],
      [ "NVXCU_FAILURE", "group__nvx__cuda__api__types.html#gga95ca9dfa832340593173124fc365b27ca0dee0ee5800d2041fdba3355d7474c1b", null ],
      [ "NVXCU_SUCCESS", "group__nvx__cuda__api__types.html#gga95ca9dfa832340593173124fc365b27ca058dc98d6f6debe7fa3eee3dd58a68c0", null ]
    ] ],
    [ "nvxcu_exec_target_type_e", "group__nvx__cuda__api__types.html#ga8544f57d469dbe3b3a17481295733559", [
      [ "NVXCU_STREAM_EXEC_TARGET", "group__nvx__cuda__api__types.html#gga8544f57d469dbe3b3a17481295733559ab277bfc6243350ee26252a5cbebdfbdf", null ]
    ] ],
    [ "nvxcu_flip_mode_e", "group__nvx__cuda__api__types.html#ga5328b4bfe41483eea16f743efc1741c4", [
      [ "NVXCU_FLIP_HORIZONTAL", "group__nvx__cuda__api__types.html#gga5328b4bfe41483eea16f743efc1741c4af2d6068b45f367a73af780291855e980", null ],
      [ "NVXCU_FLIP_VERTICAL", "group__nvx__cuda__api__types.html#gga5328b4bfe41483eea16f743efc1741c4ada3cd70f88e745a049b9e753dc756572", null ],
      [ "NVXCU_FLIP_BOTH", "group__nvx__cuda__api__types.html#gga5328b4bfe41483eea16f743efc1741c4aa8634099a5adee90622b70a38a865697", null ]
    ] ],
    [ "nvxcu_image_type_e", "group__nvx__cuda__api__types.html#gacfe7d41bcfd88556e1e6e0d30a3e811a", [
      [ "NVXCU_PITCH_LINEAR_IMAGE", "group__nvx__cuda__api__types.html#ggacfe7d41bcfd88556e1e6e0d30a3e811aa5d862d1f47107646e00b2d307fb5aecd", null ],
      [ "NVXCU_UNIFORM_IMAGE", "group__nvx__cuda__api__types.html#ggacfe7d41bcfd88556e1e6e0d30a3e811aa3e648534f540f1553cf8b0dd60399df8", null ]
    ] ],
    [ "nvxcu_interpolation_type_e", "group__nvx__cuda__api__types.html#gace988c90410f964be37e8f41d55b470f", [
      [ "NVXCU_INTERPOLATION_TYPE_NEAREST_NEIGHBOR", "group__nvx__cuda__api__types.html#ggace988c90410f964be37e8f41d55b470fa55eb1fa04214724e6a42b91a4ec0a1e3", null ],
      [ "NVXCU_INTERPOLATION_TYPE_BILINEAR", "group__nvx__cuda__api__types.html#ggace988c90410f964be37e8f41d55b470fae463b85725f30dda4fb88be984f87482", null ],
      [ "NVXCU_INTERPOLATION_TYPE_AREA", "group__nvx__cuda__api__types.html#ggace988c90410f964be37e8f41d55b470fa5c22afe0f28cd21ccfd2cfa68a9a9c8d", null ]
    ] ],
    [ "nvxcu_non_linear_filter_e", "group__nvx__cuda__api__types.html#gaf0872d4f473dc76c3767875e63713b29", [
      [ "NVXCU_NONLINEAR_FILTER_MEDIAN", "group__nvx__cuda__api__types.html#ggaf0872d4f473dc76c3767875e63713b29af92910fbdaefc3bb1137cc1fa99284d1", null ],
      [ "NVXCU_NONLINEAR_FILTER_MIN", "group__nvx__cuda__api__types.html#ggaf0872d4f473dc76c3767875e63713b29afedf28fe6bf31fa933a8ec7d6f03b77b", null ],
      [ "NVXCU_NONLINEAR_FILTER_MAX", "group__nvx__cuda__api__types.html#ggaf0872d4f473dc76c3767875e63713b29a3f2b5e4b4ef8f09a4b02874a3329b182", null ]
    ] ],
    [ "nvxcu_norm_type_e", "group__nvx__cuda__api__types.html#ga33fb88f080dfebbb65b1194b81684aa5", [
      [ "NVXCU_NORM_L1", "group__nvx__cuda__api__types.html#gga33fb88f080dfebbb65b1194b81684aa5a8e429a2566231495d7bd5b087f4ce4cc", null ],
      [ "NVXCU_NORM_L2", "group__nvx__cuda__api__types.html#gga33fb88f080dfebbb65b1194b81684aa5a7203908cfa1b809e5b9e10c6a1ef8df9", null ]
    ] ],
    [ "nvxcu_pattern_e", "group__nvx__cuda__api__types.html#gacf0ab611f84b83cd3bec7f1da8f5b79d", [
      [ "NVXCU_PATTERN_BOX", "group__nvx__cuda__api__types.html#ggacf0ab611f84b83cd3bec7f1da8f5b79da5eecc2e6fa5a19617a6016711a5503d3", null ],
      [ "NVXCU_PATTERN_CROSS", "group__nvx__cuda__api__types.html#ggacf0ab611f84b83cd3bec7f1da8f5b79da1ab5d0eaa825a4126a89126460c88add", null ],
      [ "NVXCU_PATTERN_OTHER", "group__nvx__cuda__api__types.html#ggacf0ab611f84b83cd3bec7f1da8f5b79da093eba3b896b2b279bd4c5132d3b1831", null ]
    ] ],
    [ "nvxcu_pyramid_type_e", "group__nvx__cuda__api__types.html#gac2864dd93fd49e504fcd494e95d2014e", [
      [ "NVXCU_PITCH_LINEAR_PYRAMID", "group__nvx__cuda__api__types.html#ggac2864dd93fd49e504fcd494e95d2014ea0beebffdf362c34f22f5d6c4763f7b62", null ]
    ] ],
    [ "nvxcu_round_policy_e", "group__nvx__cuda__api__types.html#gad5384032e08b30dc79fbb3cacf9166ea", [
      [ "NVXCU_ROUND_POLICY_TO_ZERO", "group__nvx__cuda__api__types.html#ggad5384032e08b30dc79fbb3cacf9166eaa960e05d35fc9f862ccba8be92e8274a0", null ],
      [ "NVXCU_ROUND_POLICY_TO_NEAREST_EVEN", "group__nvx__cuda__api__types.html#ggad5384032e08b30dc79fbb3cacf9166eaab686426ec58b53c80c0713dbb5ce8005", null ]
    ] ],
    [ "nvxcu_scanline_e", "group__nvx__cuda__api__types.html#ga39366a907611de1a5c2990180b3a3f09", [
      [ "NVXCU_SCANLINE_LEFT_RIGHT", "group__nvx__cuda__api__types.html#gga39366a907611de1a5c2990180b3a3f09a79353be9b224e581c9159a2a35a5a169", null ],
      [ "NVXCU_SCANLINE_TOP_LEFT_BOTTOM_RIGHT", "group__nvx__cuda__api__types.html#gga39366a907611de1a5c2990180b3a3f09a2ac6133194200c1f1ec7fc4b326a606f", null ],
      [ "NVXCU_SCANLINE_TOP_BOTTOM", "group__nvx__cuda__api__types.html#gga39366a907611de1a5c2990180b3a3f09a85fba1d1441e2cdbcffd2a8481d0c914", null ],
      [ "NVXCU_SCANLINE_TOP_RIGHT_BOTTOM_LEFT", "group__nvx__cuda__api__types.html#gga39366a907611de1a5c2990180b3a3f09a06c2ea84686510a3b743bcab1a9bb2cf", null ],
      [ "NVXCU_SCANLINE_RIGHT_LEFT", "group__nvx__cuda__api__types.html#gga39366a907611de1a5c2990180b3a3f09a23ab1e90da82ef5ebe82a82449f29617", null ],
      [ "NVXCU_SCANLINE_BOTTOM_RIGHT_TOP_LEFT", "group__nvx__cuda__api__types.html#gga39366a907611de1a5c2990180b3a3f09a2b75cd8b5e26523d20a52e0fa1321ab0", null ],
      [ "NVXCU_SCANLINE_BOTTOM_TOP", "group__nvx__cuda__api__types.html#gga39366a907611de1a5c2990180b3a3f09ad6dc9d49f302ecb0cb14cc71d13ec366", null ],
      [ "NVXCU_SCANLINE_BOTTOM_LEFT_TOP_RIGHT", "group__nvx__cuda__api__types.html#gga39366a907611de1a5c2990180b3a3f09a7c320241622d22a3d7c9abd73a799ef3", null ],
      [ "NVXCU_SCANLINE_CROSS", "group__nvx__cuda__api__types.html#gga39366a907611de1a5c2990180b3a3f09add2a09cd272d42d5bf15e9722ed208ca", null ],
      [ "NVXCU_SCANLINE_ALL", "group__nvx__cuda__api__types.html#gga39366a907611de1a5c2990180b3a3f09a3500d886b44e6640ea046530aac86943", null ]
    ] ],
    [ "nvxcu_sgm_flags_e", "group__nvx__cuda__api__types.html#ga11d46405b776703fd883480129072603", [
      [ "NVXCU_SGM_FILTER_TOP_AREA", "group__nvx__cuda__api__types.html#gga11d46405b776703fd883480129072603af2e6067b751a0cc978deca380a2f5f49", null ],
      [ "NVXCU_SGM_PYRAMIDAL_STEREO", "group__nvx__cuda__api__types.html#gga11d46405b776703fd883480129072603a125ff4f4a8b73525a794ba532216af53", null ]
    ] ],
    [ "nvxcu_termination_criteria_e", "group__nvx__cuda__api__types.html#ga4bb7e54d09885996dbe66d11a2bf9a5d", [
      [ "NVXCU_TERM_CRITERIA_ITERATIONS", "group__nvx__cuda__api__types.html#gga4bb7e54d09885996dbe66d11a2bf9a5da93896cf02fc6536abaff94080d24ac90", null ],
      [ "NVXCU_TERM_CRITERIA_EPSILON", "group__nvx__cuda__api__types.html#gga4bb7e54d09885996dbe66d11a2bf9a5da0c550946432a94c08ca27c171ad155be", null ],
      [ "NVXCU_TERM_CRITERIA_BOTH", "group__nvx__cuda__api__types.html#gga4bb7e54d09885996dbe66d11a2bf9a5da77aa768f167e6c221cf13666c7ad86b0", null ]
    ] ]
];