var dir_ebd5333937bf1905b9f76e4e48300725 =
[
    [ "nvx.h", "nvx_8h.html", "nvx_8h" ],
    [ "nvx_compatibility.h", "nvx__compatibility_8h.html", "nvx__compatibility_8h" ],
    [ "nvx_cuda_interop.h", "nvx__cuda__interop_8h.html", null ],
    [ "nvx_opencv_interop.hpp", "nvx__opencv__interop_8hpp.html", "nvx__opencv__interop_8hpp" ],
    [ "nvx_timer.hpp", "nvx__timer_8hpp.html", "nvx__timer_8hpp" ],
    [ "nvxcu.h", "nvxcu_8h.html", "nvxcu_8h" ]
];