var group__group__parameter =
[
    [ "vx_parameter", "group__group__parameter.html#ga35fab5fdbef16e118146d667cd98cc4d", null ],
    [ "vx_direction_e", "group__group__parameter.html#ga4a11207b7fcf1135615b4ae11624f9ed", [
      [ "VX_INPUT", "group__group__parameter.html#gga4a11207b7fcf1135615b4ae11624f9edaf035abd15d4ce563ddb52e0ae68a9585", null ],
      [ "VX_OUTPUT", "group__group__parameter.html#gga4a11207b7fcf1135615b4ae11624f9eda866b82225216ce016a62aa0a7b356ebd", null ],
      [ "VX_BIDIRECTIONAL", "group__group__parameter.html#gga4a11207b7fcf1135615b4ae11624f9edaa2abfee3a4bfec8ce3faac784a815cda", null ]
    ] ],
    [ "vx_parameter_attribute_e", "group__group__parameter.html#ga0534bb02e93eb4bab196bde2d3eccd59", [
      [ "VX_PARAMETER_INDEX", "group__group__parameter.html#gga0534bb02e93eb4bab196bde2d3eccd59a37f71b4fc94c23a2dddab551c9e6e146", null ],
      [ "VX_PARAMETER_DIRECTION", "group__group__parameter.html#gga0534bb02e93eb4bab196bde2d3eccd59a23a2785a89eab2bdc46bfbc97f17ad04", null ],
      [ "VX_PARAMETER_TYPE", "group__group__parameter.html#gga0534bb02e93eb4bab196bde2d3eccd59aa400961b57d14a87fe6644cd1a1ca904", null ],
      [ "VX_PARAMETER_STATE", "group__group__parameter.html#gga0534bb02e93eb4bab196bde2d3eccd59adec5c1d3eeb48881f23a376d4a0e3f00", null ],
      [ "VX_PARAMETER_REF", "group__group__parameter.html#gga0534bb02e93eb4bab196bde2d3eccd59a6c352e5e19f27e9b3c69314aeb48a8f6", null ]
    ] ],
    [ "vx_parameter_state_e", "group__group__parameter.html#gadee3d0820c9f76afc5273e4c1b7f3b04", [
      [ "VX_PARAMETER_STATE_REQUIRED", "group__group__parameter.html#ggadee3d0820c9f76afc5273e4c1b7f3b04a9a6a5c9c3e554763e49a4cade5294a10", null ],
      [ "VX_PARAMETER_STATE_OPTIONAL", "group__group__parameter.html#ggadee3d0820c9f76afc5273e4c1b7f3b04a7368c3309cc3038cbaaa558466d6f551", null ]
    ] ],
    [ "vxGetKernelParameterByIndex", "group__group__parameter.html#ga8eb5182219b418886155344c770e21c7", null ],
    [ "vxGetParameterByIndex", "group__group__parameter.html#gab3e64f553957ac629e4f391eb4b47fdd", null ],
    [ "vxQueryParameter", "group__group__parameter.html#ga1418cbc77cc0e5f88827874cc0eb7b96", null ],
    [ "vxReleaseParameter", "group__group__parameter.html#gade0c7bcee113a7d2eac60993d55c56e5", null ],
    [ "vxSetParameterByIndex", "group__group__parameter.html#ga3707923da464d23acec18e3fc2506286", null ],
    [ "vxSetParameterByReference", "group__group__parameter.html#gabc253eae9450dded6eb25532ad21beef", null ]
];