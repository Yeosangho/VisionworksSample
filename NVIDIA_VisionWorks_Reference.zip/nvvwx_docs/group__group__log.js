var group__group__log =
[
    [ "vx_log_callback_f", "group__group__log.html#ga1cb5484ed26e0f08d33427d6f68abd3a", null ],
    [ "vxAddLogEntry", "group__group__log.html#ga51db48e8ad9138b6099822ee79ff7ead", null ],
    [ "vxRegisterLogCallback", "group__group__log.html#gacc5f65a8a541ae596d3e857bbc9a656e", null ]
];