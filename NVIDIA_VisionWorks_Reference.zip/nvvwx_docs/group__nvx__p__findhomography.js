var group__nvx__p__findhomography =
[
    [ "nvx_find_homography_method_e", "group__nvx__p__findhomography.html#ga99bb9952b088133bbbba6034c5688a1b", [
      [ "NVX_FIND_HOMOGRAPHY_METHOD_USE_ALL_POINTS", "group__nvx__p__findhomography.html#gga99bb9952b088133bbbba6034c5688a1ba8bff3bbbeaf8dcb7c08bf5c224d351bc", null ],
      [ "NVX_FIND_HOMOGRAPHY_METHOD_RANSAC", "group__nvx__p__findhomography.html#gga99bb9952b088133bbbba6034c5688a1ba48402cf35f2b1ce154cede42bce27fb4", null ],
      [ "NVX_FIND_HOMOGRAPHY_METHOD_LMEDS", "group__nvx__p__findhomography.html#gga99bb9952b088133bbbba6034c5688a1ba940137d4ef5ca1ea359769ee5d565a71", null ]
    ] ],
    [ "nvxFindHomographyNode", "group__nvx__p__findhomography.html#gaf386362ff3c61e605559b57e00f4ce4e", null ],
    [ "nvxuFindHomography", "group__nvx__p__findhomography.html#ga1117845cf2ec9f177ad2b7b1f22f20b7", null ]
];