var group__group__vision__function__xor =
[
    [ "vxuXor", "group__group__vision__function__xor.html#ga24c790c2157df21568f1a84c8d37f9b3", null ],
    [ "vxXorNode", "group__group__vision__function__xor.html#gabfa2d00c60f459afc1b3b83561fe3f80", null ]
];