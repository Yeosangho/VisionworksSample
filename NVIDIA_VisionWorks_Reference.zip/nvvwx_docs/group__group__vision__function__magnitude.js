var group__group__vision__function__magnitude =
[
    [ "vxMagnitudeNode", "group__group__vision__function__magnitude.html#ga0dc84cdabde58c5e90879df99927037f", null ],
    [ "vxuMagnitude", "group__group__vision__function__magnitude.html#ga29c7be747372874ed9ebbb09a2bd108f", null ]
];