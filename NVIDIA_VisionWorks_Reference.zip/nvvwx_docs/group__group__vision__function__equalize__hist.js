var group__group__vision__function__equalize__hist =
[
    [ "vxEqualizeHistNode", "group__group__vision__function__equalize__hist.html#gacb77aee51865afa1a9544d5bbfadeaeb", null ],
    [ "vxuEqualizeHist", "group__group__vision__function__equalize__hist.html#gaf6d0dcd225d8005a7fca7f3554db19e9", null ]
];