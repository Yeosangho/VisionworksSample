var group__nvx__openvx =
[
    [ "OpenVX Introduction", "group__openvx__page__intro.html", null ],
    [ "OpenVX Design Overview", "group__openvx__page__design.html", null ],
    [ "OpenVX API Modules", "group__nvx__openvx__api.html", "group__nvx__openvx__api" ]
];