var group__nvx__p__multiply__by__scalar =
[
    [ "nvxMultiplyByScalarNode", "group__nvx__p__multiply__by__scalar.html#gac8eccf1082bd9b312f4c680d6fc4c405", null ],
    [ "nvxuMultiplyByScalar", "group__nvx__p__multiply__by__scalar.html#gacab06a9a93336403f8cc36b520f85543", null ]
];