var group__group__vision__function__laplacian__reconstruct =
[
    [ "vxLaplacianReconstructNode", "group__group__vision__function__laplacian__reconstruct.html#ga47e4984152a78c2f5b417430ed0073cb", null ],
    [ "vxuLaplacianReconstruct", "group__group__vision__function__laplacian__reconstruct.html#ga9162a9f6661dfc3704a77bbffa537c5b", null ]
];