var group__nvx__framework__matrix =
[
    [ "nvxMapMatrix", "group__nvx__framework__matrix.html#ga110fb9071f9ad27b4a132263a8476f46", null ],
    [ "nvxUnmapMatrix", "group__nvx__framework__matrix.html#gaffe1f9de8017c432f54f45e6b015e6fc", null ]
];