var group__nvx__opencv__interop =
[
    [ "VXImageToCVMatMapper", "classnvx__cv_1_1VXImageToCVMatMapper.html", [
      [ "VXImageToCVMatMapper", "classnvx__cv_1_1VXImageToCVMatMapper.html#afd1bb4000248395e621f16beaa62aa92", null ],
      [ "~VXImageToCVMatMapper", "classnvx__cv_1_1VXImageToCVMatMapper.html#a53d9ded017793b0c41e9a1dc05ccc9f5", null ],
      [ "getGpuMat", "classnvx__cv_1_1VXImageToCVMatMapper.html#a22bcad76ce8021c6fe3e26ab92f1d0e8", null ],
      [ "getMat", "classnvx__cv_1_1VXImageToCVMatMapper.html#a9236171406a265746e88d22e33d5ab2b", null ]
    ] ],
    [ "cloneCVMatToVXMatrix", "group__nvx__opencv__interop.html#ga2abddd7569aae2eeb470301e3c047dca", null ],
    [ "convertCVMatTypeToVXImageFormat", "group__nvx__opencv__interop.html#gad379ae9b078dfbb357d93c35948b17ac", null ],
    [ "convertCVMatTypeToVXMatrixType", "group__nvx__opencv__interop.html#gab89602839704473bdb3c8392cadf2539", null ],
    [ "convertVXImageFormatToCVMatType", "group__nvx__opencv__interop.html#ga3d8bc042e97602c02fbd8ca8889cf474", null ],
    [ "convertVXMatrixTypeToCVMatType", "group__nvx__opencv__interop.html#ga49ec9c8545227b5b106ba6208d53ab9a", null ],
    [ "copyCVMatToVXMatrix", "group__nvx__opencv__interop.html#gadcf70d3afeb66d8c642eecf4caa85100", null ],
    [ "copyVXMatrixToCVMat", "group__nvx__opencv__interop.html#gad46a6b2d7370487937fcaac6e7e8de5e", null ],
    [ "createVXImageFromCVGpuMat", "group__nvx__opencv__interop.html#gaf6fd3cd56979410076ad7f6952adbcd8", null ],
    [ "createVXImageFromCVMat", "group__nvx__opencv__interop.html#ga49389ad6e7a487f8134ed646168f2171", null ]
];