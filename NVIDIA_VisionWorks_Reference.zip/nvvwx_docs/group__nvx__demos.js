var group__nvx__demos =
[
    [ "Feature Tracker Demo App", "group__nvx__demo__feature__tracker.html", null ],
    [ "CUDA Layer Feature Tracker Demo App", "group__nvx__demo__feature__tracker__nvxcu.html", null ],
    [ "Stereo Matching Demo App", "group__nvx__sample__stereo__matching.html", null ],
    [ "CUDA Layer Object Tracker Sample App", "group__vwx__sample__object__tracker__nvxcu.html", null ],
    [ "Hough Transform Demo App", "group__vwx__sample__hough__transform.html", null ],
    [ "Video Stabilizer Demo App", "group__nvx__demo__video__stabilizer.html", null ],
    [ "Motion Estimation Demo App", "group__vwx__demo__motion__estimation.html", null ]
];