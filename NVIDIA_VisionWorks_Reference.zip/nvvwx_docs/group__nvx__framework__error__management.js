var group__nvx__framework__error__management =
[
    [ "nvx_status_e", "group__nvx__framework__error__management.html#ga4ff62489dde900fc41795ba700a0c8c0", [
      [ "NVX_ERROR_NO_CUDA_GPU", "group__nvx__framework__error__management.html#gga4ff62489dde900fc41795ba700a0c8c0a257f70b842adfaf737d2863e9eeb6bb4", null ],
      [ "NVX_ERROR_UNSUPPORTED_CUDA_GPU", "group__nvx__framework__error__management.html#gga4ff62489dde900fc41795ba700a0c8c0ab3f4808fe0dc98fb3085cfceb588fb10", null ],
      [ "NVX_ERROR_CUDA_FAILURE", "group__nvx__framework__error__management.html#gga4ff62489dde900fc41795ba700a0c8c0ab85acb97ecb22aac371a5b8fcf46915f", null ]
    ] ]
];