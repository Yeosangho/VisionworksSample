var group__nvx__framework__scalar =
[
    [ "nvxMapScalar", "group__nvx__framework__scalar.html#ga78201e57e804f36b3a1b85b5df8e32ba", null ],
    [ "nvxUnmapScalar", "group__nvx__framework__scalar.html#gaec63885bccac98647d687111d7a791e8", null ]
];