var group__group__nvxcu__render =
[
    [ "Render", "classnvxio_1_1Render.html", [
      [ "CircleStyle", "classnvxio_1_1Render.html#structnvxio_1_1Render_1_1CircleStyle", [
        [ "color", "classnvxio_1_1Render.html#a23b2c3f1abf4d7e856c762017c325b98", null ],
        [ "thickness", "classnvxio_1_1Render.html#a84e0bb846d1844558cb798419b2d2f25", null ]
      ] ],
      [ "DetectedObjectStyle", "classnvxio_1_1Render.html#structnvxio_1_1Render_1_1DetectedObjectStyle", [
        [ "color", "classnvxio_1_1Render.html#a045f7ed75f2ab2a2fc626f309346fed7", null ],
        [ "isHalfTransparent", "classnvxio_1_1Render.html#a83bc9e6fb3c9b29a595f7a849fa5ef58", null ],
        [ "label", "classnvxio_1_1Render.html#ae4aa03efdc4ca574601eb3ef08f15959", null ],
        [ "radius", "classnvxio_1_1Render.html#a5ff433575ffa5c7ac6d64f92a142fd68", null ],
        [ "thickness", "classnvxio_1_1Render.html#ae7af453a33b54faceaa680223d108541", null ]
      ] ],
      [ "FeatureStyle", "classnvxio_1_1Render.html#structnvxio_1_1Render_1_1FeatureStyle", [
        [ "color", "classnvxio_1_1Render.html#a3d37b4a84767ff531e1f62f53f033f62", null ],
        [ "radius", "classnvxio_1_1Render.html#ac1f301ba2b904d4a71433e7870ec543a", null ]
      ] ],
      [ "LineStyle", "classnvxio_1_1Render.html#structnvxio_1_1Render_1_1LineStyle", [
        [ "color", "classnvxio_1_1Render.html#a4ad75e7cc8424b073043bdc30c46d70c", null ],
        [ "thickness", "classnvxio_1_1Render.html#a6765d1688072796128e662a7070b8607", null ]
      ] ],
      [ "MotionFieldStyle", "classnvxio_1_1Render.html#structnvxio_1_1Render_1_1MotionFieldStyle", [
        [ "color", "classnvxio_1_1Render.html#a3100713a51ed98ee098a234c38e82647", null ]
      ] ],
      [ "TextBoxStyle", "classnvxio_1_1Render.html#structnvxio_1_1Render_1_1TextBoxStyle", [
        [ "bgcolor", "classnvxio_1_1Render.html#abae36baddfa310d22edbbb71b0d631b6", null ],
        [ "color", "classnvxio_1_1Render.html#acda8839dd874aa75635a5d602484cb70", null ],
        [ "origin", "classnvxio_1_1Render.html#a95b826c18dbe44971a4b9e6950575505", null ]
      ] ],
      [ "OnKeyboardEventCallback", "classnvxio_1_1Render.html#aa516ec180fb6f6ae1958cc952c98bcc5", null ],
      [ "OnMouseEventCallback", "classnvxio_1_1Render.html#abb0187ec22dc8f456d5b39eb50b0716c", null ],
      [ "MouseButtonEvent", "classnvxio_1_1Render.html#a533c5d650af100e8c8f7c7e3fd51cc13", [
        [ "LeftButtonDown", "classnvxio_1_1Render.html#a533c5d650af100e8c8f7c7e3fd51cc13aabf0eb8f54c63219ec24afce5b0dbaf0", null ],
        [ "LeftButtonUp", "classnvxio_1_1Render.html#a533c5d650af100e8c8f7c7e3fd51cc13af367b808c21baa4410d6119bcc4466ad", null ],
        [ "MiddleButtonDown", "classnvxio_1_1Render.html#a533c5d650af100e8c8f7c7e3fd51cc13a27d652a78f35c2f42e10e012e781f6ab", null ],
        [ "MiddleButtonUp", "classnvxio_1_1Render.html#a533c5d650af100e8c8f7c7e3fd51cc13a72c693f4e2fa0edaf6aa5ad1c99ce7b5", null ],
        [ "RightButtonDown", "classnvxio_1_1Render.html#a533c5d650af100e8c8f7c7e3fd51cc13aaf8e036d756d1aea80868859b725bcb0", null ],
        [ "RightButtonUp", "classnvxio_1_1Render.html#a533c5d650af100e8c8f7c7e3fd51cc13a06c48c9b436f91f280414c18a4651591", null ],
        [ "MouseMove", "classnvxio_1_1Render.html#a533c5d650af100e8c8f7c7e3fd51cc13a7fb0760f8eaea9d50dc8b17b8aabd971", null ]
      ] ],
      [ "TargetType", "classnvxio_1_1Render.html#add92074022b692db63c91d79928647ec", [
        [ "UNKNOWN_RENDER", "classnvxio_1_1Render.html#add92074022b692db63c91d79928647eca548d6c618f8c45682f12f53d1511eeb1", null ],
        [ "WINDOW_RENDER", "classnvxio_1_1Render.html#add92074022b692db63c91d79928647eca394f5c94ebdb1b360d16f48190d2e32c", null ],
        [ "VIDEO_RENDER", "classnvxio_1_1Render.html#add92074022b692db63c91d79928647ecae09e44ae9b0a2cbe658b9a381a365f52", null ],
        [ "IMAGE_RENDER", "classnvxio_1_1Render.html#add92074022b692db63c91d79928647eca1d0831fea7bd4349e363c0480f37684e", null ]
      ] ],
      [ "~Render", "classnvxio_1_1Render.html#a2acbb70513d2e06b6e11119bdde58895", null ],
      [ "Render", "classnvxio_1_1Render.html#a19ff69e11db19cc804e4f38f20931f89", null ],
      [ "close", "classnvxio_1_1Render.html#a4d93d1db8b1d0e93c1c2ccc816dbb3b6", null ],
      [ "flush", "classnvxio_1_1Render.html#a7c595cda47658f40d33f8ad5bd09a25c", null ],
      [ "getRenderName", "classnvxio_1_1Render.html#af3f5fbd298002537731af0d3804e6e68", null ],
      [ "getTargetType", "classnvxio_1_1Render.html#a91a0f370cd80450c5b34f4300acd59b5", null ],
      [ "getViewportHeight", "classnvxio_1_1Render.html#addb06dc9acd2cf9123ae321e808e3bd6", null ],
      [ "getViewportWidth", "classnvxio_1_1Render.html#a751e8e738804ba1022aba256d29fccd8", null ],
      [ "putArrows", "classnvxio_1_1Render.html#a6816f2a1c97da373da027aaf16d496b1", null ],
      [ "putCircles", "classnvxio_1_1Render.html#ad13d5cab5a8ee1384bd04c99db81c23e", null ],
      [ "putConvexPolygon", "classnvxio_1_1Render.html#aec62cf55f7f0c62531c170eb7f145819", null ],
      [ "putFeatures", "classnvxio_1_1Render.html#a3f815fa313c41b9edd77db4e5beda982", null ],
      [ "putFeatures", "classnvxio_1_1Render.html#a8436c38d6866070dfe23e8fee2e44707", null ],
      [ "putImage", "classnvxio_1_1Render.html#a65b77502af030236a41bf829dc2f8ccc", null ],
      [ "putLines", "classnvxio_1_1Render.html#a66b91eb3bbc732641fdc7fe1b0beb3bc", null ],
      [ "putMotionField", "classnvxio_1_1Render.html#a02bdd1bfdf605942a39410a95c15aba6", null ],
      [ "putObjectLocation", "classnvxio_1_1Render.html#a19ea3cdb868bd494d1438049578e70a2", null ],
      [ "putTextViewport", "classnvxio_1_1Render.html#a1f4a2ca553000738efa4d2c2a6ae74be", null ],
      [ "setOnKeyboardEventCallback", "classnvxio_1_1Render.html#ae83742d270c266c7a3d41544bc3a6a01", null ],
      [ "setOnMouseEventCallback", "classnvxio_1_1Render.html#ae4e78a171992b7fd419a70b8be6b3899", null ],
      [ "renderName", "classnvxio_1_1Render.html#a78faaa6ee6c5c326ab88f97518821308", null ],
      [ "targetType", "classnvxio_1_1Render.html#ab409e119d6f2eae5ba4d3b7bca51a064", null ]
    ] ],
    [ "createDefaultRender", "group__group__nvxcu__render.html#gaadacb092f82877f9148ac16fbbbfe46d", null ],
    [ "createImageRender", "group__group__nvxcu__render.html#ga0af7b3bde9511d57cddaa6cdbf979cfc", null ],
    [ "createVideoRender", "group__group__nvxcu__render.html#gab960c34c674613733fa54bb7a36a6d56", null ],
    [ "createWindowRender", "group__group__nvxcu__render.html#ga4feaa2a5bb30da1cf212a8b829215350", null ]
];