var group__group__delay =
[
    [ "vx_delay", "group__group__delay.html#ga2c6de63476aff4a009bac8d0eb9800d1", null ],
    [ "vx_delay_attribute_e", "group__group__delay.html#ga5c20574953e6aae4ecf01f483e2680b1", [
      [ "VX_DELAY_TYPE", "group__group__delay.html#gga5c20574953e6aae4ecf01f483e2680b1a39f3a0e0fa867dc27daf774750130db0", null ],
      [ "VX_DELAY_SLOTS", "group__group__delay.html#gga5c20574953e6aae4ecf01f483e2680b1ab9b2d40a6db1c422669cfc4c3023e666", null ]
    ] ],
    [ "vxAgeDelay", "group__group__delay.html#gacaa3be8c7c1b8aff2e6a07d7c8789ffe", null ],
    [ "vxCreateDelay", "group__group__delay.html#ga452c1671ae93d4dec19cf2875bc692fe", null ],
    [ "vxGetReferenceFromDelay", "group__group__delay.html#gac774785e6092b8bbc582cbed3a98636f", null ],
    [ "vxQueryDelay", "group__group__delay.html#gaa4e24839e45a96abd1b1e8498af8fc9a", null ],
    [ "vxReleaseDelay", "group__group__delay.html#gab61dd36e48a2bdb860bbffdd1e9539cd", null ]
];