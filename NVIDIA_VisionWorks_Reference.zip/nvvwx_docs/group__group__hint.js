var group__group__hint =
[
    [ "vx_hint_e", "group__group__hint.html#ga91f1e56c1d90a7b0ce2ab9141ef9db27", [
      [ "VX_HINT_PERFORMANCE_DEFAULT", "group__group__hint.html#gga91f1e56c1d90a7b0ce2ab9141ef9db27a7e7d311690a3cf1701a7f5c938c73153", null ],
      [ "VX_HINT_PERFORMANCE_LOW_POWER", "group__group__hint.html#gga91f1e56c1d90a7b0ce2ab9141ef9db27a92c0283f527361c09815c0be1c3b0a1f", null ],
      [ "VX_HINT_PERFORMANCE_HIGH_SPEED", "group__group__hint.html#gga91f1e56c1d90a7b0ce2ab9141ef9db27a35afe8fbd0d7e23cb0c386212a840ba2", null ]
    ] ],
    [ "vxHint", "group__group__hint.html#ga2e4f451b8e758879617cae23922af46d", null ]
];