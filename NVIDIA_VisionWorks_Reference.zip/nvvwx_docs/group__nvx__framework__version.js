var group__nvx__framework__version =
[
    [ "nvx_module_version_t", "group__nvx__framework__version.html#structnvx__module__version__t", [
      [ "major", "group__nvx__framework__version.html#a9baef1e08e3778ba15dafdeaba044856", null ],
      [ "minor", "group__nvx__framework__version.html#aafd400e5600ef2557e0f4cf504688016", null ],
      [ "patch", "group__nvx__framework__version.html#acafb17c3b6e5893f5a595cead68817b2", null ],
      [ "suffix", "group__nvx__framework__version.html#a571da986dbdfa6589744785302a4ed6c", null ]
    ] ],
    [ "nvx_version_info_t", "group__nvx__framework__version.html#structnvx__version__info__t", [
      [ "openvx_major_version", "group__nvx__framework__version.html#adca06cdb63eaf147992dfb6f493904bb", null ],
      [ "openvx_minor_version", "group__nvx__framework__version.html#add18f1edd82bc3ff156290ac94ce7511", null ],
      [ "openvx_patch_version", "group__nvx__framework__version.html#a481d28d11495419b9e92dc09beaad972", null ],
      [ "visionworks_version", "group__nvx__framework__version.html#afc4fbb9709094c5912c5d769360dc87c", null ]
    ] ],
    [ "nvxGetVersionInfo", "group__nvx__framework__version.html#gada4b9d2d72deefd12053fe777390207c", null ]
];