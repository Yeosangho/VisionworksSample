var group__nvx__tutorial__quick__start__immediate__mode =
[
    [ "Original OpenCV Code", "group__nvx__tutorial__quick__start__original__code.html", null ],
    [ "Full Code with VisionWorks", "group__nvx__tutorial__quick__start__full__code__visionworks.html", null ],
    [ "Modified Stabilizer", "group__nvx__tutorial__quick__start__modified__stabilizer.html", null ]
];