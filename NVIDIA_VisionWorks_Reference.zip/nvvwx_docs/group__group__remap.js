var group__group__remap =
[
    [ "vx_remap", "group__group__remap.html#ga4738486c2a18ba154fdc1ca154ed7325", null ],
    [ "vx_remap_attribute_e", "group__group__remap.html#gaeb825a4b63bdc742d8b4080ac0a1298c", [
      [ "VX_REMAP_SOURCE_WIDTH", "group__group__remap.html#ggaeb825a4b63bdc742d8b4080ac0a1298cad22c42925cc4c8fe2e703dcc60ab4f79", null ],
      [ "VX_REMAP_SOURCE_HEIGHT", "group__group__remap.html#ggaeb825a4b63bdc742d8b4080ac0a1298ca420dc8ac1f6bde851235be55ca0b3086", null ],
      [ "VX_REMAP_DESTINATION_WIDTH", "group__group__remap.html#ggaeb825a4b63bdc742d8b4080ac0a1298caf44116653c14ed23534e5261cf22dfc2", null ],
      [ "VX_REMAP_DESTINATION_HEIGHT", "group__group__remap.html#ggaeb825a4b63bdc742d8b4080ac0a1298caed13132d9c99091f314d39892c4fac4f", null ]
    ] ],
    [ "vxCreateRemap", "group__group__remap.html#gabd45e326f68f1c096606615fe67d8ad0", null ],
    [ "vxGetRemapPoint", "group__group__remap.html#gadf470be9db9a071bf735ab977cee25db", null ],
    [ "vxQueryRemap", "group__group__remap.html#ga930420ac10f6f24982e8d71ffa06b32b", null ],
    [ "vxReleaseRemap", "group__group__remap.html#ga745a0a51022a35cc496c98480f7ea73f", null ],
    [ "vxSetRemapPoint", "group__group__remap.html#gadd9f8ee866b4ee949ea572022ed1bc7f", null ]
];