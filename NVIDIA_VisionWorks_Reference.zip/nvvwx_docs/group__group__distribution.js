var group__group__distribution =
[
    [ "vx_distribution", "group__group__distribution.html#gae8e4d674e49a53c20b3ecd5ad80387bb", null ],
    [ "vx_distribution_attribute_e", "group__group__distribution.html#ga2df35cf9de7d83854fede1abab71c14d", [
      [ "VX_DISTRIBUTION_DIMENSIONS", "group__group__distribution.html#gga2df35cf9de7d83854fede1abab71c14da272716e770bd787318e5ae158179f38d", null ],
      [ "VX_DISTRIBUTION_OFFSET", "group__group__distribution.html#gga2df35cf9de7d83854fede1abab71c14da926108a577f77bda45892d0444ac14bc", null ],
      [ "VX_DISTRIBUTION_RANGE", "group__group__distribution.html#gga2df35cf9de7d83854fede1abab71c14dabaa957d2ac7f70931ac410e74c81baa7", null ],
      [ "VX_DISTRIBUTION_BINS", "group__group__distribution.html#gga2df35cf9de7d83854fede1abab71c14dacb64bc07705e1f6212bd24b897cf0b46", null ],
      [ "VX_DISTRIBUTION_WINDOW", "group__group__distribution.html#gga2df35cf9de7d83854fede1abab71c14da9500603088fd7e1ed994e1b2b2040f20", null ],
      [ "VX_DISTRIBUTION_SIZE", "group__group__distribution.html#gga2df35cf9de7d83854fede1abab71c14da61d58a5dc23602f1894d13e1c0123a63", null ]
    ] ],
    [ "vxCopyDistribution", "group__group__distribution.html#ga7a29416c91a499515c1302efd57fa018", null ],
    [ "vxCreateDistribution", "group__group__distribution.html#ga6c18bd81d88c4bf7f33aa1b1dfbbf62b", null ],
    [ "vxMapDistribution", "group__group__distribution.html#ga6b13448670256dc3ac859c2bfc1266df", null ],
    [ "vxQueryDistribution", "group__group__distribution.html#ga81b2fb926d644763988133a6dd8fe3cb", null ],
    [ "vxReleaseDistribution", "group__group__distribution.html#ga3b8d71ef13351f33caab08792ef3b88a", null ],
    [ "vxUnmapDistribution", "group__group__distribution.html#ga1bfe6993f74081e7baee1b45739c47f3", null ]
];