var group__nvx__tutorials =
[
    [ "User Custom Node Tutorial", "group__nvx__tutorial__user__custom__node.html", "group__nvx__tutorial__user__custom__node" ],
    [ "VisionWorks and NVXIO Basic Tutorials", "group__nvx__tutorial__basics.html", "group__nvx__tutorial__basics" ],
    [ "NVX CUDA API Tutorial", "group__nvx__tutorial__cuda__api.html", "group__nvx__tutorial__cuda__api" ],
    [ "CUDA Interoperability Tutorial", "group__nvx__tutorial__cuda__interoperability.html", "group__nvx__tutorial__cuda__interoperability" ],
    [ "EGL Stream Interoperability Tutorial", "group__nvx__tutorial__eglstream__interoperability.html", "group__nvx__tutorial__eglstream__interoperability" ],
    [ "OpenCV Interoperability Tutorial", "group__nvx__tutorial__opencv__interoperability.html", "group__nvx__tutorial__opencv__interoperability" ],
    [ "VisionWorks Quick Start (Immediate Mode)", "group__nvx__tutorial__quick__start__immediate__mode.html", "group__nvx__tutorial__quick__start__immediate__mode" ],
    [ "VisionWorks Quick Start (Graph Mode)", "group__nvx__tutorial__quick__start__graph__mode.html", "group__nvx__tutorial__quick__start__graph__mode" ]
];