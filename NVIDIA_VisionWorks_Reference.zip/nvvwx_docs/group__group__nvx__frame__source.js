var group__group__nvx__frame__source =
[
    [ "FrameSource", "classovxio_1_1FrameSource.html", [
      [ "Parameters", "structovxio_1_1FrameSource_1_1Parameters.html", [
        [ "Parameters", "structovxio_1_1FrameSource_1_1Parameters.html#ab4835065a1121a193d77cd8986b20244", null ],
        [ "format", "structovxio_1_1FrameSource_1_1Parameters.html#a4686eab73161cfd75ebac58f8b7523f1", null ],
        [ "fps", "structovxio_1_1FrameSource_1_1Parameters.html#a11a903ae97bac21f4f4671e40325a1f8", null ],
        [ "frameHeight", "structovxio_1_1FrameSource_1_1Parameters.html#a3361fd6639f6a2350fe2565758c1cd39", null ],
        [ "frameWidth", "structovxio_1_1FrameSource_1_1Parameters.html#a01b93183b2d7346bed04b581da1bdba1", null ]
      ] ],
      [ "FrameStatus", "classovxio_1_1FrameSource.html#ade384ff2cd3093a60ad68db04f228c41", [
        [ "OK", "classovxio_1_1FrameSource.html#ade384ff2cd3093a60ad68db04f228c41a436103b3202d350fb67e874dacb09f74", null ],
        [ "TIMEOUT", "classovxio_1_1FrameSource.html#ade384ff2cd3093a60ad68db04f228c41a3aa95effbdc9713aa966c90d3775c013", null ],
        [ "CLOSED", "classovxio_1_1FrameSource.html#ade384ff2cd3093a60ad68db04f228c41a4b110fef850e324a32d2475ec9307207", null ]
      ] ],
      [ "SourceType", "classovxio_1_1FrameSource.html#ac31afa12221e06eec0b0d4e27ceb7baa", [
        [ "UNKNOWN_SOURCE", "classovxio_1_1FrameSource.html#ac31afa12221e06eec0b0d4e27ceb7baaa53402cf5614509a55d4a17fc9efe235e", null ],
        [ "SINGLE_IMAGE_SOURCE", "classovxio_1_1FrameSource.html#ac31afa12221e06eec0b0d4e27ceb7baaac5131c096f05a3f9dc90404c7753f7d2", null ],
        [ "IMAGE_SEQUENCE_SOURCE", "classovxio_1_1FrameSource.html#ac31afa12221e06eec0b0d4e27ceb7baaa7022da94d5d17d75055bcea3e0ef6346", null ],
        [ "VIDEO_SOURCE", "classovxio_1_1FrameSource.html#ac31afa12221e06eec0b0d4e27ceb7baaa1cf7f1311e69c8d18f7ab978d1ac83c6", null ],
        [ "CAMERA_SOURCE", "classovxio_1_1FrameSource.html#ac31afa12221e06eec0b0d4e27ceb7baaa1bc8b629d3c9275a21f0effe439674e3", null ]
      ] ],
      [ "~FrameSource", "classovxio_1_1FrameSource.html#a71f5d49f6ef21ac34efd6501e2a9830c", null ],
      [ "FrameSource", "classovxio_1_1FrameSource.html#a6e7a52f5a15ef968bc78b42b38c4adba", null ],
      [ "close", "classovxio_1_1FrameSource.html#a3c6d33af027dde4cbe01eeeab2067551", null ],
      [ "fetch", "classovxio_1_1FrameSource.html#ae9c6a5621b782a2bae3c1ec076ff8737", null ],
      [ "getConfiguration", "classovxio_1_1FrameSource.html#ac341973ec6bb20707e3debcaf650f0f0", null ],
      [ "getSourceName", "classovxio_1_1FrameSource.html#a1b0a0ab83e54af283d42b5418abba950", null ],
      [ "getSourceType", "classovxio_1_1FrameSource.html#a1cf635abd0fb1c4ff39d7039ab074c10", null ],
      [ "open", "classovxio_1_1FrameSource.html#aedc517dcd3e1089aaac2c4c145232ded", null ],
      [ "setConfiguration", "classovxio_1_1FrameSource.html#af296d2aaeca4a34cd52f95641637b4e8", null ],
      [ "sourceName", "classovxio_1_1FrameSource.html#a476b37c098196afc246c6459f32751ed", null ],
      [ "sourceType", "classovxio_1_1FrameSource.html#aeb5af74d8cf5bfe828ca6a951f0d1d94", null ]
    ] ],
    [ "createDefaultFrameSource", "group__group__nvx__frame__source.html#ga3480d94baa6726383b71ebbad32f344a", null ],
    [ "loadImageFromFile", "group__group__nvx__frame__source.html#gac18bfd40b686cfb0cdec03a7397d68ea", null ]
];