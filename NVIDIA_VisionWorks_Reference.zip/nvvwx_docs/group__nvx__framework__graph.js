var group__nvx__framework__graph =
[
    [ "nvx_directive_e", "group__nvx__framework__graph.html#gaf3e455932240f7653b0bce4b9d5d2e9c", [
      [ "NVX_DIRECTIVE_DISABLE_KEYPOINT_ERROR", "group__nvx__framework__graph.html#ggaf3e455932240f7653b0bce4b9d5d2e9ca7fb5e448fbc9060efbadd994e2c2d2f5", null ],
      [ "NVX_DIRECTIVE_ENABLE_KEYPOINT_ERROR", "group__nvx__framework__graph.html#ggaf3e455932240f7653b0bce4b9d5d2e9cadff3b1d4604f1395f0dd46595d15aab5", null ],
      [ "NVX_DIRECTIVE_DEFAULT_KEYPOINT_ERROR", "group__nvx__framework__graph.html#ggaf3e455932240f7653b0bce4b9d5d2e9ca58baa3be6407852f88c8d4eedec6641b", null ],
      [ "NVX_DIRECTIVE_DISABLE_PERFORMANCE", "group__nvx__framework__graph.html#ggaf3e455932240f7653b0bce4b9d5d2e9ca2a5e20d185f813d7e33d2d2a67738410", null ],
      [ "NVX_DIRECTIVE_ENABLE_PERFORMANCE", "group__nvx__framework__graph.html#ggaf3e455932240f7653b0bce4b9d5d2e9ca84fe95de27128ff2f3dcebd5760c0f82", null ],
      [ "NVX_DIRECTIVE_DEFAULT_PERFORMANCE", "group__nvx__framework__graph.html#ggaf3e455932240f7653b0bce4b9d5d2e9cabd1153d5b3dca1b7de2ef979d2434a50", null ]
    ] ],
    [ "nvx_graph_attribute_e", "group__nvx__framework__graph.html#gaa6b9e8304fc1a6e4b52b517df6551f2d", [
      [ "NVX_GRAPH_VERIFY_OPTIONS", "group__nvx__framework__graph.html#ggaa6b9e8304fc1a6e4b52b517df6551f2da7734114f35b8fea102e6d3f223749f93", null ],
      [ "NVX_GRAPH_VERIFY_NEEDED", "group__nvx__framework__graph.html#ggaa6b9e8304fc1a6e4b52b517df6551f2da1cf08101d28f78e363157a237e509f91", null ]
    ] ],
    [ "nvxCreateStreamGraph", "group__nvx__framework__graph.html#ga4e1838343a1866078dff10ccabef3062", null ]
];