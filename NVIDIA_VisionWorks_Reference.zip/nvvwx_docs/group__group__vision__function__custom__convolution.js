var group__group__vision__function__custom__convolution =
[
    [ "vxConvolveNode", "group__group__vision__function__custom__convolution.html#gacb538509fd54e68bdda50eb0caa4bd9b", null ],
    [ "vxuConvolve", "group__group__vision__function__custom__convolution.html#ga045763096925998ad6872ef22805f556", null ]
];