var group__nvx__tutorial__user__custom__node =
[
    [ "1. Processing Callback Function", "group__nvx__tutorial__user__custom__node__1.html", null ],
    [ "2. Validation Callback Function", "group__nvx__tutorial__user__custom__node__2.html", null ],
    [ "3. Kernel Registration", "group__nvx__tutorial__user__custom__node__3.html", null ],
    [ "4. User Custom Node Factory", "group__nvx__tutorial__user__custom__node__4.html", null ],
    [ "5. Usage", "group__nvx__tutorial__user__custom__node__5.html", null ],
    [ "6. CUDA Nodes", "group__nvx__tutorial__user__custom__node__6.html", null ]
];