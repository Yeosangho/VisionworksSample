var group__nvx__p__laplacian =
[
    [ "nvxLaplacian3x3Node", "group__nvx__p__laplacian.html#gab0626090a8777d5acb3d72a6eef53315", null ],
    [ "nvxuLaplacian3x3", "group__nvx__p__laplacian.html#gabe6bd879b70d1a74f3e342c0d77af4cc", null ]
];