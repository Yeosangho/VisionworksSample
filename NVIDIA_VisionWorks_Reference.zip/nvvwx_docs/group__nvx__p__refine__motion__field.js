var group__nvx__p__refine__motion__field =
[
    [ "nvxRefineMotionFieldNode", "group__nvx__p__refine__motion__field.html#ga611da291d62a2962d08d1140de47310e", null ],
    [ "nvxuRefineMotionField", "group__nvx__p__refine__motion__field.html#gaf663f05d1b9fdb4f01577a249b286ce3", null ]
];