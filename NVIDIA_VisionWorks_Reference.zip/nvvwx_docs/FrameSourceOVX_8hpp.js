var FrameSourceOVX_8hpp =
[
    [ "Parameters", "structovxio_1_1FrameSource_1_1Parameters.html", "structovxio_1_1FrameSource_1_1Parameters" ],
    [ "createDefaultFrameSource", "FrameSourceOVX_8hpp.html#ga3480d94baa6726383b71ebbad32f344a", null ],
    [ "loadImageFromFile", "FrameSourceOVX_8hpp.html#gac18bfd40b686cfb0cdec03a7397d68ea", null ]
];