var group__nvx__cuda__api =
[
    [ "NVX CUDA Data Types API", "group__nvx__cuda__api__types.html", "group__nvx__cuda__api__types" ],
    [ "NVX CUDA Primitives API", "group__nvx__cuda__api__primitives.html", "group__nvx__cuda__api__primitives" ]
];