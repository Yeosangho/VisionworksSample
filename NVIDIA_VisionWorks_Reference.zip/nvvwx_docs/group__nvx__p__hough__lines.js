var group__nvx__p__hough__lines =
[
    [ "nvxHoughLinesNode", "group__nvx__p__hough__lines.html#ga0de9d605bb6b23f28e44045f4e098ee5", null ],
    [ "nvxHoughSegmentsNode", "group__nvx__p__hough__lines.html#ga69e64c4a3a2a72ac481704f1e7b3f134", null ],
    [ "nvxuHoughLines", "group__nvx__p__hough__lines.html#gaa591355deeca5bbd692fb2d5d027b68d", null ],
    [ "nvxuHoughSegments", "group__nvx__p__hough__lines.html#ga5b04b09509ab64a5b9402b4fe8729b94", null ]
];