var group__nvx__framework__convolution =
[
    [ "nvxMapConvolutionReversed", "group__nvx__framework__convolution.html#ga5ace4aeebf3afd4943aed8c4bec8b86c", null ],
    [ "nvxUnmapConvolution", "group__nvx__framework__convolution.html#gacc9e1fe9472e95b2d8c6c8dc334748d2", null ]
];