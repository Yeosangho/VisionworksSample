var group__nvx__api__modules =
[
    [ "Framework API", "group__nvx__framework.html", "group__nvx__framework" ],
    [ "Vision Primitives API", "group__nvx__primitives.html", "group__nvx__primitives" ],
    [ "OpenCV Interoperability API", "group__nvx__opencv__interop.html", "group__nvx__opencv__interop" ],
    [ "Deprecated API", "group__nvx__deprecated.html", "group__nvx__deprecated" ],
    [ "NVXIO APIs", "group__nvx__nvxio__api.html", "group__nvx__nvxio__api" ]
];