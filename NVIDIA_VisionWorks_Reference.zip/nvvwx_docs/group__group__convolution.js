var group__group__convolution =
[
    [ "vx_convolution", "group__group__convolution.html#ga03700378868a539a20db1f3302ceb4bc", null ],
    [ "vx_convolution_attribute_e", "group__group__convolution.html#gac04b5df1e74eb9ead96589ca863f1977", [
      [ "VX_CONVOLUTION_ROWS", "group__group__convolution.html#ggac04b5df1e74eb9ead96589ca863f1977a366b66a98cd918db6a8925cd3165a50a", null ],
      [ "VX_CONVOLUTION_COLUMNS", "group__group__convolution.html#ggac04b5df1e74eb9ead96589ca863f1977af7ab1678e9750b275f207c2f4a1b8820", null ],
      [ "VX_CONVOLUTION_SCALE", "group__group__convolution.html#ggac04b5df1e74eb9ead96589ca863f1977a64407834f0f38b4650b6f3ea04b04e31", null ],
      [ "VX_CONVOLUTION_SIZE", "group__group__convolution.html#ggac04b5df1e74eb9ead96589ca863f1977a3b229bce14f768a3be542b5aaa6c5bd1", null ]
    ] ],
    [ "vxCopyConvolutionCoefficients", "group__group__convolution.html#ga8d44b7ff4ec8250ef4d9cd50b20f20ad", null ],
    [ "vxCreateConvolution", "group__group__convolution.html#gada64f6e17f646dc10e15e8d1b9f3c42a", null ],
    [ "vxQueryConvolution", "group__group__convolution.html#ga5bb9b59aed131f8ec160cb4d2fc725b9", null ],
    [ "vxReleaseConvolution", "group__group__convolution.html#gab3916b17911089da2ccb90a2ded31a84", null ],
    [ "vxSetConvolutionAttribute", "group__group__convolution.html#gac449a44869d1b796105e5ffbbdb2cc0f", null ]
];