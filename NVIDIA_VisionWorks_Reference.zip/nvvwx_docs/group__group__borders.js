var group__group__borders =
[
    [ "vx_border_t", "group__group__borders.html#structvx__border__t", [
      [ "constant_value", "group__group__borders.html#a7300e66cc931397424dd02efdbc7f85a", null ],
      [ "mode", "group__group__borders.html#a443c0076d98cb53da5ae767627673b5b", null ]
    ] ],
    [ "vx_border_e", "group__group__borders.html#ga2430709469c374c6fadfac72abbbcbb4", [
      [ "VX_BORDER_UNDEFINED", "group__group__borders.html#gga2430709469c374c6fadfac72abbbcbb4aef25f2567896eb2dda48c2869030664f", null ],
      [ "VX_BORDER_CONSTANT", "group__group__borders.html#gga2430709469c374c6fadfac72abbbcbb4ad828d514964d86c5b82f1e900db2ecef", null ],
      [ "VX_BORDER_REPLICATE", "group__group__borders.html#gga2430709469c374c6fadfac72abbbcbb4a53d07d57e8b9b61974eea5eeed3df5be", null ]
    ] ],
    [ "vx_border_policy_e", "group__group__borders.html#ga146d4f89d9ade0ad70e19c6a8a7c944d", [
      [ "VX_BORDER_POLICY_DEFAULT_TO_UNDEFINED", "group__group__borders.html#gga146d4f89d9ade0ad70e19c6a8a7c944da57d12a9c56f1ac3b8ce3f15733a71e13", null ],
      [ "VX_BORDER_POLICY_RETURN_ERROR", "group__group__borders.html#gga146d4f89d9ade0ad70e19c6a8a7c944da740b228681c85753fc629a4b18c1ad94", null ]
    ] ]
];