var group__group__nvx__render =
[
    [ "FeatureStyle", "group__group__nvx__render.html#structovxio_1_1Render_1_1FeatureStyle", [
      [ "color", "group__group__nvx__render.html#a3c1813eaa82c4ac2b258b85ba8afb78c", null ],
      [ "radius", "group__group__nvx__render.html#a994aafd9196a303eac4cf164ddb10974", null ]
    ] ],
    [ "Render", "classovxio_1_1Render.html", [
      [ "CircleStyle", "classovxio_1_1Render.html#structovxio_1_1Render_1_1CircleStyle", [
        [ "color", "classovxio_1_1Render.html#a50d630d7ab749c3fa19df183b22879e6", null ],
        [ "thickness", "classovxio_1_1Render.html#a24ad318fff5a16d24adbab3c0324071d", null ]
      ] ],
      [ "DetectedObjectStyle", "classovxio_1_1Render.html#structovxio_1_1Render_1_1DetectedObjectStyle", [
        [ "color", "classovxio_1_1Render.html#a6bb3a2910a021d8ef44841b4de6353fd", null ],
        [ "isHalfTransparent", "classovxio_1_1Render.html#a2f384d1671e1b638a7bdd183ce69b5f1", null ],
        [ "label", "classovxio_1_1Render.html#a74e4a5c68d5a774eee9c0760ef80a25c", null ],
        [ "radius", "classovxio_1_1Render.html#aca06c4e6eeac59631a0150efefe421b6", null ],
        [ "thickness", "classovxio_1_1Render.html#a1151351832b5ba6d138b6e26454c6398", null ]
      ] ],
      [ "LineStyle", "classovxio_1_1Render.html#structovxio_1_1Render_1_1LineStyle", [
        [ "color", "classovxio_1_1Render.html#afd2581804eca2c566bf3d3d1d0cdd39c", null ],
        [ "thickness", "classovxio_1_1Render.html#aa1a21514cdcb5550064e50ff8dd0205f", null ]
      ] ],
      [ "MotionFieldStyle", "classovxio_1_1Render.html#structovxio_1_1Render_1_1MotionFieldStyle", [
        [ "color", "classovxio_1_1Render.html#a86ff2db87b980f15f26b1163e5b63ed2", null ]
      ] ],
      [ "OnKeyboardEventCallback", "classovxio_1_1Render.html#a84f12d78899562cfec04b4ea4b4a37b2", null ],
      [ "OnMouseEventCallback", "classovxio_1_1Render.html#a5db500bc2298f2c56dab72ff76e48565", null ],
      [ "MouseButtonEvent", "classovxio_1_1Render.html#a06bde2d800d20487af0e96c46562324d", [
        [ "LeftButtonDown", "classovxio_1_1Render.html#a06bde2d800d20487af0e96c46562324da4c5d749140853fc590c2656d96e9f5b7", null ],
        [ "LeftButtonUp", "classovxio_1_1Render.html#a06bde2d800d20487af0e96c46562324daefa18beddfe60e66a1cc49ffc32220cf", null ],
        [ "MiddleButtonDown", "classovxio_1_1Render.html#a06bde2d800d20487af0e96c46562324daebbe54eb00790a995847d9a491f4419e", null ],
        [ "MiddleButtonUp", "classovxio_1_1Render.html#a06bde2d800d20487af0e96c46562324dadce801a5b6d4bdbac56246ea4129d083", null ],
        [ "RightButtonDown", "classovxio_1_1Render.html#a06bde2d800d20487af0e96c46562324da29e2bf326ad79bc4f5afb5f02810771b", null ],
        [ "RightButtonUp", "classovxio_1_1Render.html#a06bde2d800d20487af0e96c46562324da6edb1bf2db4b23f04be095438fb76a76", null ],
        [ "MouseMove", "classovxio_1_1Render.html#a06bde2d800d20487af0e96c46562324da4a9f0a03c267f236b109a4ee62432265", null ]
      ] ],
      [ "TargetType", "classovxio_1_1Render.html#a308c0bf4876415dfd514e8c10d782e15", [
        [ "UNKNOWN_RENDER", "classovxio_1_1Render.html#a308c0bf4876415dfd514e8c10d782e15a543ea4056687faa744b4a4c72df30061", null ],
        [ "WINDOW_RENDER", "classovxio_1_1Render.html#a308c0bf4876415dfd514e8c10d782e15a912ee72a92b2e7834eb81b5fc786c1ab", null ],
        [ "VIDEO_RENDER", "classovxio_1_1Render.html#a308c0bf4876415dfd514e8c10d782e15a50a5df7157a589d618587245a8b671c0", null ],
        [ "IMAGE_RENDER", "classovxio_1_1Render.html#a308c0bf4876415dfd514e8c10d782e15a8c7c635e0cfbcc11b59cd36948219ef2", null ]
      ] ],
      [ "~Render", "classovxio_1_1Render.html#a7a8913eef2da2b07732cd7a82c33b33b", null ],
      [ "Render", "classovxio_1_1Render.html#afcc137558da4e1faf1a2a70834ba17b7", null ],
      [ "close", "classovxio_1_1Render.html#a41201b62b0b17d07cb2a437967069d27", null ],
      [ "flush", "classovxio_1_1Render.html#a7c956e487085b43ecc6e1a6a5a4cc60d", null ],
      [ "getRenderName", "classovxio_1_1Render.html#a7c8d272e9177ef9eff7e5475d6b67a06", null ],
      [ "getTargetType", "classovxio_1_1Render.html#ab803983f58fc998823daffc1b998140b", null ],
      [ "getViewportHeight", "classovxio_1_1Render.html#a9477c7c02e6a5842298d63efc62a25d5", null ],
      [ "getViewportWidth", "classovxio_1_1Render.html#a837d34721a7dfe881112f6dc75c51c9f", null ],
      [ "putArrows", "classovxio_1_1Render.html#a5d17abd33cc91f3a26a4e911cc6b8f8e", null ],
      [ "putCircles", "classovxio_1_1Render.html#a125403c5ba9a9aa8d33d1b026ee290f3", null ],
      [ "putConvexPolygon", "classovxio_1_1Render.html#a7102748446029115874917edb2d6f423", null ],
      [ "putFeatures", "classovxio_1_1Render.html#ab718461ee890c94fc8eb112b7813d6b2", null ],
      [ "putFeatures", "classovxio_1_1Render.html#a1dd92d8cc3b0ac6f7e5a846801321664", null ],
      [ "putImage", "classovxio_1_1Render.html#ad5fa48ce1da6d42dd8cfe97cff12ed65", null ],
      [ "putLines", "classovxio_1_1Render.html#aec14ecabf8703a5e0d92058cfcecd36a", null ],
      [ "putMotionField", "classovxio_1_1Render.html#acfbc75894e39935f11f462aa02efd75c", null ],
      [ "putObjectLocation", "classovxio_1_1Render.html#a41f4e75e4f8c207b74a158f8ff59681b", null ],
      [ "putTextViewport", "classovxio_1_1Render.html#a3c1e2eeb496d185bf8e7427dd9a1d324", null ],
      [ "setOnKeyboardEventCallback", "classovxio_1_1Render.html#abf50653e846d08b5f2d35ce976f14793", null ],
      [ "setOnMouseEventCallback", "classovxio_1_1Render.html#a298301b12e8841153b36a5f2596823d5", null ],
      [ "renderName", "classovxio_1_1Render.html#ad5730ce80db6c3207242affc934e0f5d", null ],
      [ "targetType", "classovxio_1_1Render.html#a39c764e669c0df691619cf1b8aea713d", null ]
    ] ],
    [ "TextBoxStyle", "group__group__nvx__render.html#structovxio_1_1Render_1_1TextBoxStyle", [
      [ "bgcolor", "group__group__nvx__render.html#a86469fd16baf501ad0a927aea5d36008", null ],
      [ "color", "group__group__nvx__render.html#a8eca20c95bee40bf789dc7a4f92479de", null ],
      [ "origin", "group__group__nvx__render.html#afdd60cf664eb9b63243bb87a54c247d7", null ]
    ] ],
    [ "createDefaultRender", "group__group__nvx__render.html#gaa0b492061a0db5c0a8d20f546ccd1a40", null ],
    [ "createImageRender", "group__group__nvx__render.html#gade282d71ab36726c47151572a9833688", null ],
    [ "createVideoRender", "group__group__nvx__render.html#ga9b18f4b29b9b997a8305a12fba4b2532", null ],
    [ "createWindowRender", "group__group__nvx__render.html#ga54b3cfb27057cbcab8d572771c68526a", null ]
];