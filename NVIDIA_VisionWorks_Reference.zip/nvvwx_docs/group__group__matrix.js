var group__group__matrix =
[
    [ "vx_matrix", "group__group__matrix.html#ga58694f635229a5e16823013ac75396f4", null ],
    [ "vx_matrix_attribute_e", "group__group__matrix.html#ga0f2d532b5ae14affed791440c0d06f65", [
      [ "VX_MATRIX_TYPE", "group__group__matrix.html#gga0f2d532b5ae14affed791440c0d06f65a725e188b989d46642ff88645dc5a5093", null ],
      [ "VX_MATRIX_ROWS", "group__group__matrix.html#gga0f2d532b5ae14affed791440c0d06f65af7c8b9456addaa908f795486af947197", null ],
      [ "VX_MATRIX_COLUMNS", "group__group__matrix.html#gga0f2d532b5ae14affed791440c0d06f65ad9fdd8ceb33878c580f74ab8bb4d37f1", null ],
      [ "VX_MATRIX_SIZE", "group__group__matrix.html#gga0f2d532b5ae14affed791440c0d06f65a30718d35a305834abb2c26488cf61e16", null ],
      [ "VX_MATRIX_ORIGIN", "group__group__matrix.html#gga0f2d532b5ae14affed791440c0d06f65ae9f138b8a4856e6616fb65a3ee69d59d", null ],
      [ "VX_MATRIX_PATTERN", "group__group__matrix.html#gga0f2d532b5ae14affed791440c0d06f65a02ec0e766e6e5f42d86396376b369017", null ]
    ] ],
    [ "vxCopyMatrix", "group__group__matrix.html#ga5a4912312011b9dbcf9230bd588d41f7", null ],
    [ "vxCreateMatrix", "group__group__matrix.html#ga60469797e6ebfc529887330ab076468c", null ],
    [ "vxCreateMatrixFromPattern", "group__group__matrix.html#gaaae7d1d6326ba50503b8ce4035bda8e6", null ],
    [ "vxQueryMatrix", "group__group__matrix.html#ga01d66f34892895d9d084f194afb935bd", null ],
    [ "vxReleaseMatrix", "group__group__matrix.html#gacdef85532d0a821070ec2aa0a6395b40", null ]
];