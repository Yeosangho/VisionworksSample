var group__group__node__callback =
[
    [ "vx_action", "group__group__node__callback.html#ga80014c261e13aeff37fcd6b0c9ef0f2c", null ],
    [ "vx_nodecomplete_f", "group__group__node__callback.html#ga7f33f2fa408e270f690d800d117328f3", null ],
    [ "vx_action_e", "group__group__node__callback.html#ga28324bfc81fd9121efb8c1ec416d507a", [
      [ "VX_ACTION_CONTINUE", "group__group__node__callback.html#gga28324bfc81fd9121efb8c1ec416d507aadd0aa8a90d3dbe6baf709e42999c6d11", null ],
      [ "VX_ACTION_ABANDON", "group__group__node__callback.html#gga28324bfc81fd9121efb8c1ec416d507aa10be7ca7e2b02f0a815c109b97ccd291", null ]
    ] ],
    [ "vxAssignNodeCallback", "group__group__node__callback.html#ga04a77098044842c96b6945c1eeb06509", null ],
    [ "vxRetrieveNodeCallback", "group__group__node__callback.html#ga815d8e87c2ef376cf5590ba0d815dd72", null ]
];