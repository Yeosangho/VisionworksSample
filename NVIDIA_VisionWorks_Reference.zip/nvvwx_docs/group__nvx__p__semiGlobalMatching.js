var group__nvx__p__semiGlobalMatching =
[
    [ "nvx_scanline_e", "group__nvx__p__semiGlobalMatching.html#gac6d0c12c94f68c9ae15396a6d4198a30", [
      [ "NVX_SCANLINE_LEFT_RIGHT", "group__nvx__p__semiGlobalMatching.html#ggac6d0c12c94f68c9ae15396a6d4198a30a40128ba34ed1e17ec35d738b4cca0fc2", null ],
      [ "NVX_SCANLINE_TOP_LEFT_BOTTOM_RIGHT", "group__nvx__p__semiGlobalMatching.html#ggac6d0c12c94f68c9ae15396a6d4198a30a198ef52c5ee132126f6b67d6e553ef3c", null ],
      [ "NVX_SCANLINE_TOP_BOTTOM", "group__nvx__p__semiGlobalMatching.html#ggac6d0c12c94f68c9ae15396a6d4198a30abc435a4c4b2e025bd7e889756fb2fe42", null ],
      [ "NVX_SCANLINE_TOP_RIGHT_BOTTOM_LEFT", "group__nvx__p__semiGlobalMatching.html#ggac6d0c12c94f68c9ae15396a6d4198a30a5e1b2e2fab4c1bcb11bc56a2610b6cd2", null ],
      [ "NVX_SCANLINE_RIGHT_LEFT", "group__nvx__p__semiGlobalMatching.html#ggac6d0c12c94f68c9ae15396a6d4198a30a2e44fbf00ec31460823803daf11f9414", null ],
      [ "NVX_SCANLINE_BOTTOM_RIGHT_TOP_LEFT", "group__nvx__p__semiGlobalMatching.html#ggac6d0c12c94f68c9ae15396a6d4198a30a6dedc3b22902bfe8c4e632162ced112c", null ],
      [ "NVX_SCANLINE_BOTTOM_TOP", "group__nvx__p__semiGlobalMatching.html#ggac6d0c12c94f68c9ae15396a6d4198a30a4c82ad48def0d98b6f026d00305bc658", null ],
      [ "NVX_SCANLINE_BOTTOM_LEFT_TOP_RIGHT", "group__nvx__p__semiGlobalMatching.html#ggac6d0c12c94f68c9ae15396a6d4198a30aef14b76bb6d9c7dcc681998db34a7aa7", null ],
      [ "NVX_SCANLINE_CROSS", "group__nvx__p__semiGlobalMatching.html#ggac6d0c12c94f68c9ae15396a6d4198a30a91141e9a1eb1a0301b7c3d42c613713c", null ],
      [ "NVX_SCANLINE_ALL", "group__nvx__p__semiGlobalMatching.html#ggac6d0c12c94f68c9ae15396a6d4198a30a79401b09636ee64723595dd33add30eb", null ]
    ] ],
    [ "nvx_sgm_flags_e", "group__nvx__p__semiGlobalMatching.html#ga860ae295c3b93b6ea88a4d1a1aee62ce", [
      [ "NVX_SGM_FILTER_TOP_AREA", "group__nvx__p__semiGlobalMatching.html#gga860ae295c3b93b6ea88a4d1a1aee62ceac46b7fbf561826eba3c53200f58dd244", null ],
      [ "NVX_SGM_PYRAMIDAL_STEREO", "group__nvx__p__semiGlobalMatching.html#gga860ae295c3b93b6ea88a4d1a1aee62ceadafb15d0f888ec933e90d018ea7888e3", null ]
    ] ],
    [ "nvxAggregateCostScanlinesNode", "group__nvx__p__semiGlobalMatching.html#ga828218b41a9d75632b49cee948e832c1", null ],
    [ "nvxCensusTransformNode", "group__nvx__p__semiGlobalMatching.html#ga8216a98f6a9b5337bf8358ed7c703218", null ],
    [ "nvxComputeCostBTNode", "group__nvx__p__semiGlobalMatching.html#ga09d6116220cac93bd67419ee84a98d7e", null ],
    [ "nvxComputeCostHammingNode", "group__nvx__p__semiGlobalMatching.html#gaf7dabeef22b9f3129adecd7294b064c3", null ],
    [ "nvxComputeDisparityNode", "group__nvx__p__semiGlobalMatching.html#gaa01f7796a884a7beaba3c67de107ffc7", null ],
    [ "nvxComputeModifiedCostBTNode", "group__nvx__p__semiGlobalMatching.html#ga44388efdb0b313b551c6194510033814", null ],
    [ "nvxConvolveCostNode", "group__nvx__p__semiGlobalMatching.html#ga2eedfb0747833efe25b775060588a0aa", null ],
    [ "nvxFilterCostNode", "group__nvx__p__semiGlobalMatching.html#ga275daba7d13e78518aadc365c8e86aaf", null ],
    [ "nvxPSGMCostPriorNode", "group__nvx__p__semiGlobalMatching.html#gab6777d789bf36f822719589741ec2f46", null ],
    [ "nvxPSGMDisparityMergeNode", "group__nvx__p__semiGlobalMatching.html#gae513818f10ca2df3d6d1460fb2c4f406", null ],
    [ "nvxSemiGlobalMatchingNode", "group__nvx__p__semiGlobalMatching.html#ga34b0ca1c0424d4e6cb4e95e6a567e1b4", null ],
    [ "nvxuAggregateCostScanlines", "group__nvx__p__semiGlobalMatching.html#ga08a66b4bd67f1202ae8eb603d865d259", null ],
    [ "nvxuCensusTransform", "group__nvx__p__semiGlobalMatching.html#ga56a0530a80c62d5cb4aeb2ced287a56e", null ],
    [ "nvxuComputeCostBT", "group__nvx__p__semiGlobalMatching.html#ga94d311fa9c0861dff1e9260c52c9083f", null ],
    [ "nvxuComputeCostHamming", "group__nvx__p__semiGlobalMatching.html#ga0f9ab42c19775ace0540f0a44133fc62", null ],
    [ "nvxuComputeDisparity", "group__nvx__p__semiGlobalMatching.html#ga1278c142f381f36b11e6c968d76cc127", null ],
    [ "nvxuComputeModifiedCostBT", "group__nvx__p__semiGlobalMatching.html#ga921ee1b261152bfa8a8ddf28a2cb54a1", null ],
    [ "nvxuConvolveCost", "group__nvx__p__semiGlobalMatching.html#ga1582aa0a62a09100dd24d48fefcd277d", null ],
    [ "nvxuFilterCost", "group__nvx__p__semiGlobalMatching.html#ga65864616c38e74cfd58b9477d1d65cc1", null ],
    [ "nvxuPSGMCostPrior", "group__nvx__p__semiGlobalMatching.html#ga9d8ac1684d0893ea1b6868855d05304d", null ],
    [ "nvxuPSGMDisparityMerge", "group__nvx__p__semiGlobalMatching.html#ga85e190d0c3463dc6626228178b77b061", null ],
    [ "nvxuSemiGlobalMatching", "group__nvx__p__semiGlobalMatching.html#ga0a8f69c5f28190d686416d1160375873", null ]
];