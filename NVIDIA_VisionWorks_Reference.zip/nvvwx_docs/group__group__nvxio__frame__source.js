var group__group__nvxio__frame__source =
[
    [ "VisionWorks FrameSource Interface", "group__group__nvx__frame__source.html", "group__group__nvx__frame__source" ],
    [ "VisionWorks CUDA FrameSource Interface", "group__group__nvxcu__frame__source.html", "group__group__nvxcu__frame__source" ]
];