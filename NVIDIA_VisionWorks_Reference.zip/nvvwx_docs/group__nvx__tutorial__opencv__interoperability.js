var group__nvx__tutorial__opencv__interoperability =
[
    [ "Conversion Between OpenCV and OpenVX Data Types", "group__nvx__tutorial__opencv__interoperability__1.html", null ],
    [ "Differences Between OpenCV and VisionWorks Primitives", "group__nvx__tutorial__opencv__interoperability__2.html", null ]
];