var group__nvx__openvx__api =
[
    [ "Vision Functions", "group__group__vision__functions.html", "group__group__vision__functions" ],
    [ "Basic Features", "group__group__basic__features.html", "group__group__basic__features" ],
    [ "Administrative Features", "group__group__administrative__features.html", "group__group__administrative__features" ]
];