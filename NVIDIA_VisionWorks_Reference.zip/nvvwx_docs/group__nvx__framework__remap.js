var group__nvx__framework__remap =
[
    [ "nvxMapRemapPatch", "group__nvx__framework__remap.html#ga8666e93cb598d234e33398e85eea1de5", null ],
    [ "nvxUnmapRemapPatch", "group__nvx__framework__remap.html#ga58acff1303ad447210181b5b77fc52d2", null ]
];