var group__group__performance =
[
    [ "vx_perf_t", "group__group__performance.html#structvx__perf__t", [
      [ "avg", "group__group__performance.html#ae5462847dea84081b46e1b9ee7f39121", null ],
      [ "beg", "group__group__performance.html#abb283d5564a3d785736448c223800a52", null ],
      [ "end", "group__group__performance.html#adae6b5d0c938176c81e3527cbbe41e0b", null ],
      [ "max", "group__group__performance.html#ac029bfb16aa32e7859108d348ec426b0", null ],
      [ "min", "group__group__performance.html#ad1606f8c397b230151c1230eb178a777", null ],
      [ "num", "group__group__performance.html#af25ea855b02f3d2f94e50d87898a80ad", null ],
      [ "sum", "group__group__performance.html#a7f18945629adba34a23bf66a959560e8", null ],
      [ "tmp", "group__group__performance.html#a07b019ddbe5e6b1f62c07dd3b2d1c23e", null ]
    ] ]
];