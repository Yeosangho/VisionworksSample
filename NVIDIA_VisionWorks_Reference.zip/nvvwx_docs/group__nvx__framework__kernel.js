var group__nvx__framework__kernel =
[
    [ "nvx_mutability_e", "group__nvx__framework__kernel.html#gaa5b2dd6cf45771a8593411d994685eec", [
      [ "NVX_MUTABLE_INIT", "group__nvx__framework__kernel.html#ggaa5b2dd6cf45771a8593411d994685eeca311ecfcc041dc59da870aae8eab950d2", null ],
      [ "NVX_METADATA_IMMUTABLE_INIT", "group__nvx__framework__kernel.html#ggaa5b2dd6cf45771a8593411d994685eecab36d86d7ded3070fdf2b3c3814d9f895", null ],
      [ "NVX_IMMUTABLE_INIT", "group__nvx__framework__kernel.html#ggaa5b2dd6cf45771a8593411d994685eeca6bbce0174621395c958f5ab7c0767bbc", null ]
    ] ],
    [ "nvxSetKernelParameterMutability", "group__nvx__framework__kernel.html#gac250603be84260501b8cea93dbdd4314", null ]
];