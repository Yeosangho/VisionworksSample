var group__group__vision__function__sub =
[
    [ "vxSubtractNode", "group__group__vision__function__sub.html#gaf98964b5a630a53a62c4583ec996b88f", null ],
    [ "vxuSubtract", "group__group__vision__function__sub.html#ga1a49d0c0ef5e016d3b65d7335e471cf4", null ]
];